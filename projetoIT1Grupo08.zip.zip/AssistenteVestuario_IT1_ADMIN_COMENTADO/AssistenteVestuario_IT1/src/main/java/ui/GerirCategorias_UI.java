package ui;

import controller.GerirCategorias_Controller;
import domain.Categoria;
import domain.Plataforma;
import utils.Utils;

import java.util.ArrayList;
import java.util.List;

/** interface de consola do uc02 - gerir categorias. */
public class GerirCategorias_UI
{
    private final GerirCategorias_Controller controller;

    public GerirCategorias_UI(Plataforma plataforma)
    { /* este método prepara uma nova instância desta classe. */
        this.controller = new GerirCategorias_Controller(plataforma);
    }

    /** executa criar, editar ou remover categoria. */
    public void run()
    { /* este método executa o fluxo principal deste caso de uso. */  // permite adicionar, editar ou remover categorias
        System.out.println("\n=== Gerir Categorias ===");
        if (!controller.temPermissaoAdministrador()) // só o administrador pode alterar as categorias
        {
            System.out.println("Acesso reservado ao administrador.");
            return;
        }
        List<String> operacoes = List.of("Adicionar", "Editar", "Remover");
        String operacao = Utils.apresentaESeleciona(operacoes, "Selecione a operação:", "Voltar");
        if (operacao == null) return;

        switch (operacao)
        {
            case "Adicionar" -> adicionar();
            case "Editar" -> editar();
            case "Remover" -> remover();
            default -> { }
        }
    }

    private void adicionar()
    { /* este método adiciona um elemento. */
        String erro;
        do
        {
            controller.novaCategoria(Utils.readLineFromConsole("Introduza o nome da categoria: "));
            erro = controller.validar();
            if (erro != null && !corrigirOuCancelar(erro)) return;
        } while (erro != null);

        System.out.println("\nDados da categoria:\n" + controller.obterDados());
        if (!Utils.confirma("Confirma os dados? (S/N)")) return;
        System.out.println(controller.registarCategoria()
                ? "Categoria registada com sucesso."
                : "Não foi possível registar a categoria.");
    }

    private void editar()
    { /* este método edita . */
        List<Categoria> categorias = controller.getCategorias();
        if (categorias.isEmpty())
        {
            System.out.println("Não existem categorias para editar.");
            return;
        }
        Categoria categoria = Utils.apresentaESeleciona(categorias, "Selecione a categoria a editar:", "Voltar");
        if (categoria == null) return;
        controller.selecionarCategoria(categoria);

        String novoNome;
        String erro;
        do
        {
            novoNome = Utils.readLineFromConsole("Novo nome da categoria: ");
            erro = controller.validarNovoNome(novoNome);
            if (erro != null && !corrigirOuCancelar(erro)) return;
        } while (erro != null);

        if (!Utils.confirma("Confirma a alteração para '" + novoNome + "'? (S/N)")) return;
        System.out.println(controller.editarCategoria(novoNome)
                ? "Categoria alterada com sucesso."
                : "Não foi possível alterar a categoria.");
    }

    private void remover()
    { /* este método remove . */
        List<Categoria> categorias = controller.getCategorias();
        if (categorias.isEmpty())
        {
            System.out.println("Não existem categorias para remover.");
            return;
        }
        Categoria categoria = Utils.apresentaESeleciona(categorias, "Selecione a categoria a remover:", "Voltar");
        if (categoria == null) return;
        controller.selecionarCategoria(categoria);

        int associadas = controller.contarPecasAssociadas();
        Categoria destino = null;
        if (associadas > 0)
        {
            System.out.println("A categoria tem " + associadas + " peça(s) associada(s). É necessário reatribuí-las.");
            List<Categoria> alternativas = new ArrayList<>(controller.getCategorias());
            alternativas.remove(categoria);
            if (alternativas.isEmpty())
            {
                System.out.println("Não existe outra categoria. A remoção não é possível.");
                return;
            }
            destino = Utils.apresentaESeleciona(alternativas, "Selecione a categoria de destino:", "Cancelar");
            if (destino == null) return;
        }

        if (!Utils.confirma("Confirma a remoção de '" + categoria + "'? (S/N)")) return;
        System.out.println(controller.removerCategoria(destino)
                ? "Categoria removida com sucesso."
                : "Não foi possível remover a categoria.");
    }

    private boolean corrigirOuCancelar(String erro)
    { /* este método trata um erro e permite corrigir ou cancelar. */
        System.out.println("--> " + erro);
        if (Utils.confirma("Pretende corrigir os dados? (S/N)")) return true;
        System.out.println("Operação cancelada.");
        return false;
    }
}
