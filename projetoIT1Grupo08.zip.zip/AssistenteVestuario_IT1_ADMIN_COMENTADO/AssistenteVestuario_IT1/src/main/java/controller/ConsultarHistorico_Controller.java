package controller;

import domain.Plataforma;
import domain.SugestaoRoupa;

import java.util.List;

/**
 * controlador grasp do uc08 - consultar histórico.
 */
public class ConsultarHistorico_Controller {
    private final Plataforma plataforma;

    public ConsultarHistorico_Controller(Plataforma plataforma) { /* este método prepara uma nova instância desta classe. */
        this.plataforma = plataforma;
    }

    /**
     * @return true se existe utilizador autenticado
     */
    public boolean temUtilizadorAtivo() { /* este método verifica se utilizador ativo. */
        return plataforma.temUtilizadorAtivo();
    }

    /**
     * @return histórico do utilizador atual
     */
    public List<SugestaoRoupa> getHistoricoSugestoes() { /* este método devolve historico sugestoes. */
        return plataforma.getHistoricoSugestoes();
    }

    /**
     * @return detalhe de uma sugestão
     */
    public String getDetalheSugestao(SugestaoRoupa sugestao) { /* este método devolve detalhe sugestao. */
        return plataforma.getDetalheSugestao(sugestao);
    }
}
