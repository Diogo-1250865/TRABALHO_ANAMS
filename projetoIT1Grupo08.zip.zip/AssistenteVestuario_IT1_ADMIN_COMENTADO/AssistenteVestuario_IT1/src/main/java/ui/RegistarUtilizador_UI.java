package ui;

import controller.RegistarUtilizador_Controller;
import domain.Plataforma;
import utils.Utils;

/**
 * interface de consola do uc01 - registar utilizador.
 *
 * @author diogo
 */
public class RegistarUtilizador_UI
{
    private final RegistarUtilizador_Controller controller;

    public RegistarUtilizador_UI(Plataforma plataforma)
    { /* este método prepara uma nova instância desta classe. */
        this.controller = new RegistarUtilizador_Controller(plataforma);
    }

    public void run()
    { /* este método executa o fluxo principal deste caso de uso. */
        System.out.println("\n=== Registar Utilizador ===");
        controller.novoUtilizador();

        String erro;
        do
        {
            introduzDados();
            erro = controller.validar();
            if (erro != null)
            {
                System.out.println("--> " + erro);
                if (!Utils.confirma("Pretende corrigir os dados? (S/N)"))
                {
                    System.out.println("Operação cancelada.");
                    return;
                }
            }
        } while (erro != null);

        System.out.println("\nDados do utilizador:\n" + controller.obterDados());

        if (Utils.confirma("Confirma os dados? (S/N)"))
        {
            if (controller.registarUtilizador())
            {
                System.out.println("Utilizador registado com sucesso. A sessão ficou iniciada com esta conta.");
            } else
            {
                System.out.println("Não foi possível registar o utilizador.");
            }
        } else
        {
            System.out.println("Operação cancelada.");
        }
    }

    private void introduzDados()
    { /* este método recolhe e introduz dados. */
        String nome = Utils.readLineFromConsole("Introduza o nome: ");
        String email = Utils.readLineFromConsole("Introduza o email: ");
        String palavraPasse = Utils.readLineFromConsole("Introduza a palavra-passe: ");
        controller.setDados(nome, email, palavraPasse);
    }
}
