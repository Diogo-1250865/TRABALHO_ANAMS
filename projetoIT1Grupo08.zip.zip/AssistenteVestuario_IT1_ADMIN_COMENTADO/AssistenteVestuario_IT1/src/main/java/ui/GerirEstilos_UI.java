package ui;

import controller.GerirEstilos_Controller;
import domain.Estilo;
import domain.Plataforma;
import utils.Utils;

import java.util.ArrayList;
import java.util.List;

/** interface de consola do uc03 - gerir estilos. */
public class GerirEstilos_UI
{
    private final GerirEstilos_Controller controller;

    public GerirEstilos_UI(Plataforma plataforma)
    { /* este método prepara uma nova instância desta classe. */
        this.controller = new GerirEstilos_Controller(plataforma);
    }

    /** executa criar, editar ou remover estilo. */
    public void run()
    { /* este método executa o fluxo principal deste caso de uso. */
        System.out.println("\n=== Gerir Estilos ===");
        if (!controller.temPermissaoAdministrador())
        {
            System.out.println("Acesso reservado ao administrador.");
            return;
        }
        String operacao = Utils.apresentaESeleciona(List.of("Adicionar", "Editar", "Remover"),
                "Selecione a operação:", "Voltar");
        if (operacao == null) return;
        switch (operacao)
        {
            case "Adicionar" -> adicionar();
            case "Editar" -> editar();
            case "Remover" -> remover();
            default -> { }
        }
    }

    private void adicionar()
    { /* este método adiciona um elemento. */
        String erro;
        do
        {
            controller.novoEstilo(Utils.readLineFromConsole("Introduza o nome do estilo: "));
            erro = controller.validar();
            if (erro != null && !corrigirOuCancelar(erro)) return;
        } while (erro != null);
        System.out.println("\nDados do estilo:\n" + controller.obterDados());
        if (!Utils.confirma("Confirma os dados? (S/N)")) return;
        System.out.println(controller.registarEstilo() ? "Estilo registado com sucesso." : "Não foi possível registar o estilo.");
    }

    private void editar()
    { /* este método edita . */
        List<Estilo> estilos = controller.getEstilos();
        if (estilos.isEmpty())
        {
            System.out.println("Não existem estilos para editar.");
            return;
        }
        Estilo estilo = Utils.apresentaESeleciona(estilos, "Selecione o estilo a editar:", "Voltar");
        if (estilo == null) return;
        controller.selecionarEstilo(estilo);

        String novoNome;
        String erro;
        do
        {
            novoNome = Utils.readLineFromConsole("Novo nome do estilo: ");
            erro = controller.validarNovoNome(novoNome);
            if (erro != null && !corrigirOuCancelar(erro)) return;
        } while (erro != null);

        if (!Utils.confirma("Confirma a alteração para '" + novoNome + "'? (S/N)")) return;
        System.out.println(controller.editarEstilo(novoNome) ? "Estilo alterado com sucesso." : "Não foi possível alterar o estilo.");
    }

    private void remover()
    { /* este método remove . */
        List<Estilo> estilos = controller.getEstilos();
        if (estilos.isEmpty())
        {
            System.out.println("Não existem estilos para remover.");
            return;
        }
        Estilo estilo = Utils.apresentaESeleciona(estilos, "Selecione o estilo a remover:", "Voltar");
        if (estilo == null) return;
        controller.selecionarEstilo(estilo);

        int associadas = controller.contarPecasAssociadas();
        Estilo destino = null;
        if (associadas > 0)
        {
            System.out.println("O estilo tem " + associadas + " peça(s) associada(s). É necessário reatribuí-las.");
            List<Estilo> alternativas = new ArrayList<>(controller.getEstilos());
            alternativas.remove(estilo);
            if (alternativas.isEmpty())
            {
                System.out.println("Não existe outro estilo. A remoção não é possível.");
                return;
            }
            destino = Utils.apresentaESeleciona(alternativas, "Selecione o estilo de destino:", "Cancelar");
            if (destino == null) return;
        }

        if (!Utils.confirma("Confirma a remoção de '" + estilo + "'? (S/N)")) return;
        System.out.println(controller.removerEstilo(destino) ? "Estilo removido com sucesso." : "Não foi possível remover o estilo.");
    }

    private boolean corrigirOuCancelar(String erro)
    { /* este método trata um erro e permite corrigir ou cancelar. */ // mostra o erro e pergunta se o utilizador quer corrigir os dados
        System.out.println("--> " + erro);
        if (Utils.confirma("Pretende corrigir os dados? (S/N)")) return true;
        System.out.println("Operação cancelada.");
        return false;
    }
}
