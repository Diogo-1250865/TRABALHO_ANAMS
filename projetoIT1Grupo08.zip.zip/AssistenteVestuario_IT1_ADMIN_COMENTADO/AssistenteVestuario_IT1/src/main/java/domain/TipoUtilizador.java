package domain;

import java.io.Serializable;

/**
 * define os dois tipos de conta usados pela aplicação.
 */
public enum TipoUtilizador implements Serializable      // distinção entre utilizador e administrador
{
    UTILIZADOR,
    ADMINISTRADOR
}
