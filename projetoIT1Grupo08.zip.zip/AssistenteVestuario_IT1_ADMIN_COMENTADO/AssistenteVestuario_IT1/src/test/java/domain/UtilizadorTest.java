package domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class UtilizadorTest
{
    @Test
    void dadosCorretosSaoValidos()
    { /* este teste verifica: dados corretos são válidos. */
        assertTrue(new Utilizador("Ana", "ana@isep.ipp.pt", "segredo123").valida());
    }

    @Test
    void utilizadorPorOmissaoNaoEValido()
    { /* este teste verifica: utilizador por omissão não é válido. */
        assertFalse(new Utilizador().valida());
    }

    @Test
    void emailsInvalidosSaoRejeitados()
    { /* este teste verifica: emails inválidos são rejeitados. */
        String[] invalidos = {"", "   ", "semarroba.com", "@isep.pt", "ana@", "ana@isep", "ana@isep.", "a@b@c.com", "a na@isep.pt"};
        for (String email : invalidos)
        {
            assertFalse(new Utilizador("Ana", email, "segredo123").valida(), "Devia ser inválido: '" + email + "'");
        }
    }

    @Test
    void palavraPasseCurtaERejeitada()
    { /* este teste verifica: palavra-passe curta é rejeitada. */
        assertFalse(new Utilizador("Ana", "ana@isep.ipp.pt", "curta").valida());
        assertTrue(new Utilizador("Ana", "ana@isep.ipp.pt", "12345678").valida());
    }

    @Test
    void nomeEmFaltaERejeitado()
    { /* este teste verifica: nome em falta é rejeitado. */
        assertFalse(new Utilizador("  ", "ana@isep.ipp.pt", "segredo123").valida());
        assertFalse(new Utilizador(null, "ana@isep.ipp.pt", "segredo123").valida());
    }

    @Test
    void obterDadosNaoRevelaAPalavraPasse()
    { /* este método devolve dados nao revela apalavra passe. */
        Utilizador u = new Utilizador("Ana", "ana@isep.ipp.pt", "segredo123");
        assertFalse(u.obterDados().contains("segredo123"));
        assertFalse(u.toString().contains("segredo123"));
    }

    @Test
    void comparacaoDeEmailNaoDistingueMaiusculas()
    { /* este teste verifica: comparação de email não distingue maiúsculas. */
        assertTrue(new Utilizador("Ana", "Ana@ISEP.pt", "segredo123").temEmail("ana@isep.pt"));
    }

    @Test
    void autenticaComPalavraPasseCorreta()
    { /* este método verifica as credenciais e autentica o utilizador. */
        Utilizador u = new Utilizador("Ana", "ana@isep.ipp.pt", "segredo123");
        assertTrue(u.autentica("segredo123"));
        assertFalse(u.autentica("segredo999"));
    }

}
