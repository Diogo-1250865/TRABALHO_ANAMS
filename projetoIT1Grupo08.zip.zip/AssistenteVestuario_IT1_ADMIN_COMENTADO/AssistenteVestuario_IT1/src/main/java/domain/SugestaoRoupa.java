package domain;

import java.io.Serializable;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * sugestão de roupa: uma peça por categoria selecionada, para um contexto e estilo.
 * mantém o proprietário para que histórico e avaliações fiquem isolados por utilizador.
 */
public class SugestaoRoupa implements Serializable
{
    private static final long serialVersionUID = 1L;
    private static final DateTimeFormatter FORMATO_DATA = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private final Utilizador proprietario;
    private final ContextoUtilizacao contexto;
    private final Estilo estilo;
    private final List<Categoria> categoriasSelecionadas;
    private final List<PecaVestuario> pecas;
    private final List<Categoria> categoriasSemPeca;
    private final LocalDateTime data;
    private Avaliacao avaliacao;

    /** cria uma sugestão sem proprietário explícito (compatibilidade com testes). */
    public SugestaoRoupa(ContextoUtilizacao contexto, Estilo estilo, List<Categoria> categoriasSelecionadas)
    { /* este método prepara uma nova instância desta classe. */
        this(null, contexto, estilo, categoriasSelecionadas);
    }

    /** cria uma sugestão para o utilizador indicado. */
    public SugestaoRoupa(Utilizador proprietario, ContextoUtilizacao contexto, Estilo estilo,
                         List<Categoria> categoriasSelecionadas)
    { /* este método prepara uma nova instância desta classe. */
        this.proprietario = proprietario;
        this.contexto = contexto == null ? null : contexto.copia();
        this.estilo = estilo == null ? null : new Estilo(estilo.getNome());
        this.categoriasSelecionadas = categoriasSelecionadas == null
                ? new ArrayList<>() : new ArrayList<>(categoriasSelecionadas);
        this.pecas = new ArrayList<>();
        this.categoriasSemPeca = new ArrayList<>();
        this.data = LocalDateTime.now();
        this.avaliacao = null;
    }

    /** @return utilizador a quem pertence a sugestão */
    public Utilizador getProprietario() { /* este método devolve proprietario. */ return proprietario; }
    /** @return snapshot do contexto */
    public ContextoUtilizacao getContexto() { /* este método devolve contexto. */ return contexto; }
    /** @return snapshot do estilo */
    public Estilo getEstilo() { /* este método devolve estilo. */ return estilo; }
    /** @return cópia das categorias selecionadas */
    public List<Categoria> getCategoriasSelecionadas() { /* este método devolve categorias selecionadas. */ return new ArrayList<>(categoriasSelecionadas); }
    /** @return cópia das peças sugeridas */
    public List<PecaVestuario> getPecas() { /* este método devolve pecas. */ return new ArrayList<>(pecas); }
    /** @return categorias sem peça adequada */
    public List<Categoria> getCategoriasSemPeca() { /* este método devolve categorias sem peca. */ return new ArrayList<>(categoriasSemPeca); }
    /** @return data da sugestão */
    public LocalDateTime getData() { /* este método devolve data. */ return data; }

    /** adiciona uma peça à sugestão. */
    public void addPeca(PecaVestuario peca)
    { /* este método adiciona peca. */
        if (peca != null) pecas.add(peca);
    }

    /** regista uma categoria sem alternativa adequada. */
    public void addCategoriaSemPeca(Categoria categoria)
    { /* este método adiciona categoria sem peca. */
        if (categoria != null && !categoriasSemPeca.contains(categoria)) categoriasSemPeca.add(categoria);
    }

    /** @return true se já existe avaliação */
    public boolean isAvaliada() { /* este método indica se avaliada. */ return avaliacao != null; }
    /** @return avaliação ou null */
    public Avaliacao getAvaliacao() { /* este método devolve avaliacao. */ return avaliacao; }
    /** @param avaliacao avaliação a associar */
    public void setAvaliacao(Avaliacao avaliacao) { /* este método atualiza avaliacao. */ this.avaliacao = avaliacao; }
    /** @return true se contém a peça */
    public boolean contemPeca(PecaVestuario peca) { /* este método indica se a sugestão inclui a peça. */ return pecas.contains(peca); }

    /** procura a peça atualmente sugerida para uma categoria. */
    public PecaVestuario getPecaDaCategoria(Categoria categoria)
    { /* este método devolve peca da categoria. */
        for (PecaVestuario p : pecas)
        {
            if (p.getCategoria().equals(categoria)) return p;
        }
        return null;
    }

    /**
     * troca a peça de uma categoria por outra alternativa.
     *
     * @param categoria categoria a alterar
     * @param novaPeca nova peça; null remove a categoria da sugestão
     */
    public void substituirPeca(Categoria categoria, PecaVestuario novaPeca)
    { /* este método substitui peca. */
        pecas.removeIf(p -> p.getCategoria().equals(categoria));
        categoriasSemPeca.remove(categoria);
        if (novaPeca == null) addCategoriaSemPeca(categoria);
        else addPeca(novaPeca);
    }

    /** @return true se a sugestão é estruturalmente válida */
    public boolean valida()
    { /* este método valida os dados do objeto. */
        if (contexto == null || estilo == null || pecas.isEmpty()) return false;
        List<Categoria> usadas = new ArrayList<>();
        for (PecaVestuario p : pecas)
        {
            Categoria c = p.getCategoria();
            if (usadas.contains(c) || !categoriasSelecionadas.contains(c)) return false;
            if (proprietario != null && p.getProprietario() != null && p.getProprietario() != proprietario) return false;
            usadas.add(c);
        }
        return true;
    }

    /** @return texto multilinha com a sugestão */
    public String obterSugestao()
    { /* este método devolve sugestao. */
        StringBuilder sb = new StringBuilder();
        sb.append("Contexto: ").append(contexto).append("\n");
        sb.append("Estilo: ").append(estilo).append("\n");
        sb.append("Peças sugeridas:\n");
        for (PecaVestuario p : pecas)
        {
            sb.append("  - ").append(p.getCategoria()).append(": ").append(p).append("\n");
        }
        if (!categoriasSemPeca.isEmpty())
        {
            sb.append("Sem peça adequada para: ").append(categoriasSemPeca).append("\n");
        }
        return sb.toString();
    }

    /** @return detalhe com contexto, peças e avaliação */
    public String obterDetalhe()
    { /* este método devolve detalhe. */
        return "Data: " + data.format(FORMATO_DATA) + "\n"
                + obterSugestao()
                + "Avaliação: " + (isAvaliada() ? avaliacao.obterDados() : "ainda não avaliada") + "\n";
    }

    @Override
    public String toString()
    { /* este método devolve uma representação do objeto em texto. */
        return data.format(FORMATO_DATA) + " | " + contexto + " | " + estilo
                + " | " + pecas.size() + " peça(s) | "
                + (isAvaliada() ? "avaliada " + avaliacao.getPontuacao() + "/" + Avaliacao.PONTUACAO_MAXIMA : "por avaliar");
    }
}
