package domain;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * repositório central do domínio (singleton). mantém as entidades e concentra
 * validações globais, integridade referencial e filtragem por utilizador ativo.
 * corresponde ao objeto ":plataforma" dos diagramas de sequência.
 */
public class Plataforma implements Serializable
{
    private static final long serialVersionUID = 1L;
    private static final String PROPRIEDADE_FICHEIRO_DADOS = "assistente.dados.ficheiro";
    private static final String FICHEIRO_DADOS_POR_OMISSAO = "dados/assistente-vestuario.dat";
    private static final double PONTUACAO_NEUTRA = 3.0;
    private static final String NOME_ADMIN_INICIAL = "Administrador";
    private static final String EMAIL_ADMIN_INICIAL = "admin@vestuario.pt";
    private static final String PALAVRA_PASSE_ADMIN_INICIAL = "Admin1234!";
    private static Plataforma instancia;

    private final List<Utilizador> utilizadores;
    private final List<Categoria> categorias;
    private final List<Estilo> estilos;
    private final List<PecaVestuario> pecas;
    private final List<ContextoUtilizacao> contextos;
    private final List<SugestaoRoupa> sugestoes;
    private transient Utilizador utilizadorAtual;

    /**
     * obtém a única instância partilhada da plataforma. na primeira chamada tenta
     * recuperar automaticamente o estado gravado em disco. se ainda não existir
     * ficheiro de dados, inicia a aplicação com os dados base.
     *
     * @return única instância partilhada da plataforma
     */
    public static synchronized Plataforma getInstance()       // garante que existe uma única plataforma
    { /* este método devolve instance. */
        if (instancia == null)
        {
            instancia = carregarDoDisco();
            if (instancia == null)
            {
                instancia = new Plataforma();
            }
            // por segurança, uma sessão nunca fica autenticada depois de reiniciar o programa.
            instancia.utilizadorAtual = null;  // os dados são recuperados, a sessão não
            if (instancia.garantirAdministradorInicial())
            {
                instancia.guardarDados();
            }
        }
        return instancia;
    }

    /** construtor package-private para testes isolados. */
    Plataforma()
    { /* este método prepara uma nova instância desta classe. */
        utilizadores = new ArrayList<>();
        categorias = new ArrayList<>();
        estilos = new ArrayList<>();
        pecas = new ArrayList<>();
        contextos = new ArrayList<>();
        sugestoes = new ArrayList<>();
        utilizadorAtual = null;
        carregarDadosIniciais();
    }

    private void carregarDadosIniciais()  // carrega as categorias e os estilos iniciais e garante o administrador
    { /* este método carrega dados iniciais. */
        for (String nome : new String[]{"T-shirts", "Camisas", "Camisolas", "Calças", "Calções",
                "Casacos", "Calçado", "Acessórios"})
        {
            categorias.add(new Categoria(nome));
        }
        for (String nome : new String[]{"Casual", "Formal", "Desportivo", "Elegante"})
        {
            estilos.add(new Estilo(nome));
        }
        garantirAdministradorInicial();
    }

    private boolean garantirAdministradorInicial() // se não existir administrador, cria o inicial (devolve true se o criou)
    { /* este método garante administrador inicial. */
        for (Utilizador utilizador : utilizadores)
        {
            if (utilizador.isAdministrador())
            {
                return false;
            }
        }
        utilizadores.add(new Utilizador(NOME_ADMIN_INICIAL, EMAIL_ADMIN_INICIAL,
                PALAVRA_PASSE_ADMIN_INICIAL, TipoUtilizador.ADMINISTRADOR));
        return true;
    }

    // ===================== memoria permanente =====================

    /**
     * caminho do ficheiro de dados. por omissão fica dentro da pasta "dados" do projeto.
     * pode ser alterado com a propriedade de sistema "assistente.dados.ficheiro".
     */
    private static Path caminhoDados()
    { /* este método devolve o caminho usado para guardar os dados. */
        return Path.of(System.getProperty(PROPRIEDADE_FICHEIRO_DADOS, FICHEIRO_DADOS_POR_OMISSAO));
    }

    /** tenta recuperar o estado integral da aplicação guardado numa execução anterior. */
    private static Plataforma carregarDoDisco() // lê o ficheiro .dat e devolve a plataforma guardada (null se não existir ou não puder ser lido)
    { /* este método carrega do disco. */
        Path ficheiro = caminhoDados();
        if (!Files.exists(ficheiro))
        {
            return null;
        }

        try (ObjectInputStream entrada = new ObjectInputStream(Files.newInputStream(ficheiro)))
        {
            Object objeto = entrada.readObject();
            if (objeto instanceof Plataforma plataforma)
            {
                System.out.println("Dados anteriores carregados de: " + ficheiro.toAbsolutePath());
                return plataforma;
            }
        }
        catch (IOException | ClassNotFoundException e)
        {
            System.err.println("Aviso: não foi possível carregar os dados guardados. "
                    + "Será iniciada uma nova sessão de dados. Motivo: " + e.getMessage());
        }
        return null;
    }

    /**
     * guarda de forma persistente todos os utilizadores, categorias, estilos, peças,
     * contextos, sugestões e avaliações. a gravação é feita primeiro num ficheiro
     * temporário para reduzir o risco de corrupção se a aplicação for interrompida.
     */
    public synchronized void guardarDados()
    { /* este método guarda dados. */
        Path ficheiro = caminhoDados();
        Path pasta = ficheiro.toAbsolutePath().getParent();
        Path temporario = ficheiro.resolveSibling(ficheiro.getFileName() + ".tmp");

        try
        {
            if (pasta != null)
            {
                Files.createDirectories(pasta);
            }
            try (ObjectOutputStream saida = new ObjectOutputStream(Files.newOutputStream(temporario,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE)))
            {
                saida.writeObject(this);
            }

            try
            {
                Files.move(temporario, ficheiro, StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            }
            catch (AtomicMoveNotSupportedException e)
            {
                Files.move(temporario, ficheiro, StandardCopyOption.REPLACE_EXISTING);
            }
        }
        catch (IOException e)
        {
            System.err.println("Aviso: não foi possível guardar os dados em "
                    + ficheiro.toAbsolutePath() + ": " + e.getMessage());
        }
    }

    /** @return localização do ficheiro persistente, útil para mostrar ao utilizador. */
    public String getLocalizacaoFicheiroDados()
    { /* este método devolve localizacao ficheiro dados. */
        return caminhoDados().toAbsolutePath().toString();
    }

    // ===================== sessão / autenticação =====================

    /** @return utilizadores registados */
    public List<Utilizador> getUtilizadores()
    { /* este método devolve utilizadores. */
        return new ArrayList<>(utilizadores);
    }

    /** @return utilizador autenticado/ativo, ou null */
    public Utilizador getUtilizadorAtual()
    { /* este método devolve utilizador atual. */
        return utilizadorAtual;
    }

    /** @return true quando existe utilizador autenticado */
    public boolean temUtilizadorAtivo()
    { /* este método verifica se utilizador ativo. */
        return utilizadorAtual != null;
    }

    public boolean utilizadorAtualEhAdministrador()
    { /* este método verifica se o utilizador atual é administrador. */
        return utilizadorAtual != null && utilizadorAtual.isAdministrador();
    }

    public String getEmailAdministradorInicial()
    { /* este método devolve email administrador inicial. */
        return EMAIL_ADMIN_INICIAL;
    }

    /**
     * autentica um utilizador por email e palavra-passe e torna-o ativo.
     *
     * @return true se as credenciais são válidas
     */
    public boolean autenticar(String email, String palavraPasse)
    { /* este método verifica as credenciais e autentica o utilizador. */
        for (Utilizador u : utilizadores)
        {
            if (u.temEmail(email) && u.autentica(palavraPasse))
            {
                utilizadorAtual = u;
                return true;
            }
        }
        return false;
    }

    /** termina a sessão do utilizador atual. */
    public void terminarSessao()
    { /* este método termina a sessão atual. */
        utilizadorAtual = null;
    }

    /** permite aos testes/fluxos internos selecionar diretamente um utilizador registado. */
    public boolean selecionarUtilizador(Utilizador utilizador)
    { /* este método seleciona utilizador. */
        if (utilizador != null && utilizadores.contains(utilizador))
        {
            utilizadorAtual = utilizador;
            return true;
        }
        return false;
    }

    // ===================== uc01 - registar utilizador =====================

    /** @return novo utilizador por preencher */
    public Utilizador criarUtilizador()
    { /* este método cria ou prepara utilizador. */
        return new Utilizador();
    }

    /** @return true se o email já está registado */
    public boolean existeUtilizadorComEmail(String email)
    { /* este método verifica se existe utilizador com email. */
        return utilizadores.stream().anyMatch(u -> u.temEmail(email));
    }

    /** regista o utilizador e inicia sessão com a nova conta. */
    public boolean registarUtilizador(Utilizador utilizador)
    { /* este método regista utilizador. */
        if (!validarUtilizador(utilizador)) return false;
        utilizadores.add(utilizador);
        utilizadorAtual = utilizador;
        guardarDados();
        return true;
    }

    private boolean validarUtilizador(Utilizador utilizador)
    { /* este método valida utilizador. */
        return utilizador != null && utilizador.valida() && !existeUtilizadorComEmail(utilizador.getEmail());
    }

    // ===================== uc02 - gerir categorias =====================

    /** @return cópia das categorias disponíveis */
    public List<Categoria> getCategorias()
    { /* este método devolve categorias. */
        return new ArrayList<>(categorias);
    }

    /** cria uma categoria ainda não registada. */
    public Categoria criarCategoria(String nome)
    { /* este método cria ou prepara categoria. */
        return new Categoria(nome);
    }

    /** @return true se existe categoria equivalente */
    public boolean existeCategoria(Categoria categoria)
    { /* este método verifica se existe categoria. */
        return categorias.contains(categoria);
    }

    /** regista uma nova categoria válida e não duplicada. */
    public boolean registarCategoria(Categoria categoria)
    { /* este método regista categoria. */
        if (categoria == null || !categoria.valida() || existeCategoria(categoria)) return false;
        categorias.add(categoria);
        guardarDados();
        return true;
    }

    /**
     * altera o nome de uma categoria mantendo as referências das peças.
     *
     * @param categoria categoria existente
     * @param novoNome novo nome
     * @return true se alterada
     */
    public boolean editarCategoria(Categoria categoria, String novoNome)
    { /* este método edita categoria. */
        Categoria real = categoriaCanonica(categoria);
        Categoria candidata = new Categoria(novoNome);
        if (real == null || !candidata.valida()) return false;
        for (Categoria c : categorias)
        {
            if (c != real && c.equals(candidata)) return false;
        }
        real.setNome(novoNome);
        guardarDados();
        return true;
    }

    /** @return número de peças associadas à categoria */
    public int contarPecasDaCategoria(Categoria categoria)
    { /* este método conta pecas da categoria. */
        int total = 0;
        for (PecaVestuario p : pecas) if (p.getCategoria().equals(categoria)) total++;
        return total;
    }

    /**
     * remove uma categoria. quando existem peças associadas, exige uma categoria de destino.
     *
     * @param categoria categoria a remover
     * @param destino categoria para reatribuição; pode ser null quando não há peças associadas
     * @return true se removida
     */
    public boolean removerCategoria(Categoria categoria, Categoria destino)
    { /* este método remove categoria. */
        Categoria alvo = categoriaCanonica(categoria);
        if (alvo == null) return false;
        List<PecaVestuario> associadas = pecas.stream().filter(p -> p.getCategoria().equals(alvo)).toList();
        Categoria destinoReal = destino == null ? null : categoriaCanonica(destino);
        if (!associadas.isEmpty())
        {
            if (destinoReal == null || destinoReal == alvo) return false;
            for (PecaVestuario p : associadas) p.setCategoria(destinoReal);
        }
        boolean removida = categorias.remove(alvo);
        if (removida) guardarDados();
        return removida;
    }

    private Categoria categoriaCanonica(Categoria categoria)
    { /* este método devolve a categoria registada equivalente (a instância guardada), ou null. */
        if (categoria == null) return null;
        for (Categoria c : categorias) if (c.equals(categoria)) return c;
        return null;
    }

    // ===================== uc03 - gerir estilos =====================

    /** @return cópia dos estilos disponíveis */
    public List<Estilo> getEstilos()
    { /* este método devolve estilos. */
        return new ArrayList<>(estilos);
    }

    /** cria um estilo ainda não registado. */
    public Estilo criarEstilo(String nome)
    { /* este método cria ou prepara estilo. */
        return new Estilo(nome);
    }

    /** @return true se existe estilo equivalente */
    public boolean existeEstilo(Estilo estilo)
    { /* este método verifica se existe estilo. */
        return estilos.contains(estilo);
    }

    /** regista um novo estilo válido e não duplicado. */
    public boolean registarEstilo(Estilo estilo)
    { /* este método regista estilo. */
        if (estilo == null || !estilo.valida() || existeEstilo(estilo)) return false;
        estilos.add(estilo);
        guardarDados();
        return true;
    }

    /** altera o nome de um estilo existente. */
    public boolean editarEstilo(Estilo estilo, String novoNome)
    { /* este método edita estilo. */
        Estilo real = estiloCanonico(estilo);
        Estilo candidato = new Estilo(novoNome);
        if (real == null || !candidato.valida()) return false;
        for (Estilo e : estilos)
        {
            if (e != real && e.equals(candidato)) return false;
        }
        real.setNome(novoNome);
        guardarDados();
        return true;
    }

    /** @return número de peças associadas ao estilo */
    public int contarPecasDoEstilo(Estilo estilo)
    { /* este método conta pecas do estilo. */
        int total = 0;
        for (PecaVestuario p : pecas) if (p.getEstilo().equals(estilo)) total++;
        return total;
    }

    /** remove um estilo, reatribuindo peças quando necessário. */
    public boolean removerEstilo(Estilo estilo, Estilo destino)
    { /* este método remove estilo. */
        Estilo alvo = estiloCanonico(estilo);
        if (alvo == null) return false;
        List<PecaVestuario> associadas = pecas.stream().filter(p -> p.getEstilo().equals(alvo)).toList();
        Estilo destinoReal = destino == null ? null : estiloCanonico(destino);
        if (!associadas.isEmpty())
        {
            if (destinoReal == null || destinoReal == alvo) return false;
            for (PecaVestuario p : associadas) p.setEstilo(destinoReal);
        }
        boolean removido = estilos.remove(alvo);
        if (removido) guardarDados();
        return removido;
    }

    private Estilo estiloCanonico(Estilo estilo)
    { /* este método devolve o estilo registado equivalente (a instância guardada), ou null. */
        if (estilo == null) return null;
        for (Estilo e : estilos) if (e.equals(estilo)) return e;
        return null;
    }

    // ===================== uc04 - registar peça =====================

    /** @return peças do utilizador atual; sem sessão devolve todas (útil para testes) */
    public List<PecaVestuario> getPecas()
    { /* este método devolve pecas. */
        if (utilizadorAtual == null) return new ArrayList<>(pecas);
        return pecas.stream().filter(p -> p.getProprietario() == utilizadorAtual).toList();
    }

    /** cria uma peça associada ao utilizador atual. */
    public PecaVestuario criarPeca(String nome, Categoria categoria, Estilo estilo,
                                   String cor, String tamanho, String marca, String fotografia)
    { /* este método cria ou prepara peca. */
        Categoria c = categoriaCanonica(categoria);
        Estilo e = estiloCanonico(estilo);
        return new PecaVestuario(utilizadorAtual, nome, c == null ? categoria : c,
                e == null ? estilo : e, cor, tamanho, marca, fotografia);
    }

    /** @return true se existe peça igual do mesmo proprietário */
    public boolean existePeca(PecaVestuario peca)
    { /* este método verifica se existe peca. */
        if (peca == null) return false;
        for (PecaVestuario existente : pecas)
        {
            if (Objects.equals(existente.getProprietario(), peca.getProprietario()) && existente.equals(peca)) return true;
        }
        return false;
    }

    /** @return true se categoria e estilo estão registados */
    public boolean categoriaEEstiloExistem(PecaVestuario peca)
    { /* este método verifica se a categoria e o estilo da peça estão registados. */
        return peca != null && categoriaCanonica(peca.getCategoria()) != null && estiloCanonico(peca.getEstilo()) != null;
    }

    /** regista uma peça válida e associa-a ao utilizador atual quando aplicável. */
    public boolean registarPeca(PecaVestuario peca)
    { /* este método regista peca. */
        if (peca == null) return false;
        if (peca.getProprietario() == null && utilizadorAtual != null) peca.setProprietario(utilizadorAtual);
        if (!peca.valida() || !categoriaEEstiloExistem(peca) || existePeca(peca)) return false;
        pecas.add(peca);
        guardarDados();
        return true;
    }

    // ===================== uc05 - gerir contextos =====================

    /** @return contextos do utilizador atual; sem sessão devolve todos */
    public List<ContextoUtilizacao> getContextos()
    { /* este método devolve contextos. */
        if (utilizadorAtual == null) return new ArrayList<>(contextos);
        return contextos.stream().filter(c -> c.getProprietario() == utilizadorAtual).toList();
    }

    /** @return novo contexto associado ao utilizador atual */
    public ContextoUtilizacao novoContexto()
    { /* este método cria ou prepara contexto. */
        return new ContextoUtilizacao(utilizadorAtual, "a definir", "a definir", "a definir");
    }

    /** @return true se existe contexto igual para o mesmo utilizador */
    public boolean existeContexto(ContextoUtilizacao contexto)
    { /* este método verifica se existe contexto. */
        if (contexto == null) return false;
        for (ContextoUtilizacao existente : contextos)
        {
            if (Objects.equals(existente.getProprietario(), contexto.getProprietario()) && existente.equals(contexto)) return true;
        }
        return false;
    }

    /** regista um contexto válido do utilizador atual, rejeitando duplicados desse mesmo utilizador. */
    public boolean registarContexto(ContextoUtilizacao contexto)
    { /* este método regista contexto. */
        if (contexto == null) return false;
        if (contexto.getProprietario() == null && utilizadorAtual != null) contexto.setProprietario(utilizadorAtual);
        if (!contexto.valida() || existeContexto(contexto)) return false;
        contextos.add(contexto);
        guardarDados();
        return true;
    }

    /** altera um contexto, rejeitando duplicados do mesmo utilizador. */
    public boolean editarContexto(ContextoUtilizacao contexto, String ocasiao, String clima, String formalidade)
    { /* este método edita contexto. */
        if (contexto == null || !contextos.contains(contexto)) return false;
        ContextoUtilizacao candidato = new ContextoUtilizacao(contexto.getProprietario(), ocasiao, clima, formalidade);
        if (!candidato.valida()) return false;
        for (ContextoUtilizacao c : contextos)
        {
            if (c != contexto && Objects.equals(c.getProprietario(), contexto.getProprietario()) && c.equals(candidato)) return false;
        }
        contexto.setOcasiao(ocasiao);
        contexto.setClima(clima);
        contexto.setFormalidade(formalidade);
        guardarDados();
        return true;
    }

    /** remove um contexto. sugestões antigas preservam um snapshot do contexto. */
    public boolean removerContexto(ContextoUtilizacao contexto)
    { /* este método remove contexto. */
        boolean removido = contexto != null && contextos.remove(contexto);
        if (removido) guardarDados();
        return removido;
    }

    // ===================== uc06 - sugerir roupa =====================

    /**
     * devolve categorias com pelo menos uma peça compatível com o estilo e o contexto.
     * o clima fica registado no contexto; em it1 não existem propriedades térmicas nas peças.
     */
    public List<Categoria> getCategoriasDisponiveis(ContextoUtilizacao contexto, Estilo estilo)
    { /* este método devolve categorias disponiveis. */
        List<Categoria> disponiveis = new ArrayList<>();
        if (contexto == null || estilo == null || !contexto.valida() || !contexto.compativelCom(estilo)) return disponiveis;
        for (Categoria c : categorias)
        {
            if (escolherPeca(c, estilo, null, utilizadorAtual) != null) disponiveis.add(c);
        }
        return disponiveis;
    }

    /** cria uma sugestão para o utilizador atual. */
    public SugestaoRoupa criarSugestao(List<Categoria> categoriasSelecionadas,
                                       ContextoUtilizacao contexto, Estilo estilo)
    { /* este método cria ou prepara sugestao. */
        SugestaoRoupa sugestao = new SugestaoRoupa(utilizadorAtual, contexto, estilo, categoriasSelecionadas);
        if (contexto == null || estilo == null || !contexto.compativelCom(estilo)) return sugestao;
        for (Categoria c : sugestao.getCategoriasSelecionadas())
        {
            PecaVestuario peca = escolherPeca(c, estilo, null, utilizadorAtual);
            if (peca == null) sugestao.addCategoriaSemPeca(c);
            else sugestao.addPeca(peca);
        }
        return sugestao;
    }

    /**
     * troca apenas uma peça da sugestão por outra da mesma categoria.
     *
     * @return true se existia alternativa
     */
    public boolean trocarPecaSugestao(SugestaoRoupa sugestao, Categoria categoria)
    { /* este método troca peca sugestao. */
        if (sugestao == null || categoria == null) return false;
        PecaVestuario atual = sugestao.getPecaDaCategoria(categoria);
        PecaVestuario alternativa = escolherPeca(categoria, sugestao.getEstilo(), atual, sugestao.getProprietario());
        if (alternativa == null) return false;
        sugestao.substituirPeca(categoria, alternativa);
        // se a sugestão já pertence ao histórico, a alteração também fica persistida.
        if (sugestoes.contains(sugestao)) guardarDados();
        return true;
    }

    private PecaVestuario escolherPeca(Categoria categoria, Estilo estilo, PecaVestuario excluir, Utilizador dono)
    { /* este método escolhe a peça com melhor pontuação média para a categoria e o estilo. */
        PecaVestuario melhor = null;
        double melhorPontuacao = -1;
        for (PecaVestuario p : pecas)
        {
            boolean donoCompativel = dono == null || p.getProprietario() == null || p.getProprietario() == dono;
            if (donoCompativel && p != excluir && p.getCategoria().equals(categoria) && p.getEstilo().equals(estilo))
            {
                double pontuacao = pontuacaoMedia(p, dono);
                if (pontuacao > melhorPontuacao)
                {
                    melhor = p;
                    melhorPontuacao = pontuacao;
                }
            }
        }
        return melhor;
    }

    private double pontuacaoMedia(PecaVestuario peca, Utilizador dono)
    { /* este método calcula a pontuação média das avaliações de uma peça. */
        int soma = 0;
        int total = 0;
        for (SugestaoRoupa s : sugestoes)
        {
            boolean mesmoDono = dono == null || s.getProprietario() == null || s.getProprietario() == dono;
            if (mesmoDono && s.isAvaliada() && s.contemPeca(peca))
            {
                soma += s.getAvaliacao().getPontuacao();
                total++;
            }
        }
        return total == 0 ? PONTUACAO_NEUTRA : (double) soma / total;
    }

    /** regista uma sugestão válida no histórico do respetivo utilizador. */
    public boolean registarSugestao(SugestaoRoupa sugestao)
    { /* este método regista sugestao. */
        if (sugestao == null || !sugestao.valida() || sugestoes.contains(sugestao)) return false;
        if (utilizadorAtual != null && sugestao.getProprietario() != utilizadorAtual) return false;
        sugestoes.add(sugestao);
        guardarDados();
        return true;
    }

    // ===================== uc07 - avaliar sugestão =====================

    /** cria uma avaliação ainda não registada. */
    public Avaliacao criarAvaliacao(int pontuacao, String comentario)
    { /* este método cria ou prepara avaliacao. */
        return new Avaliacao(pontuacao, comentario);
    }

    /** regista uma única avaliação válida numa sugestão do utilizador atual. */
    public boolean registarAvaliacao(SugestaoRoupa sugestao, Avaliacao avaliacao)
    { /* este método regista avaliacao. */
        if (sugestao == null || avaliacao == null || !avaliacao.valida()
                || !sugestoes.contains(sugestao) || sugestao.isAvaliada()) return false;
        if (utilizadorAtual != null && sugestao.getProprietario() != utilizadorAtual) return false;
        sugestao.setAvaliacao(avaliacao);
        guardarDados();
        return true;
    }

    // ===================== uc08 - consultar histórico =====================

    /** @return histórico do utilizador atual; sem sessão devolve todos (testes) */
    public List<SugestaoRoupa> getHistoricoSugestoes()
    { /* este método devolve historico sugestoes. */
        if (utilizadorAtual == null) return new ArrayList<>(sugestoes);
        return sugestoes.stream().filter(s -> s.getProprietario() == utilizadorAtual).toList();
    }

    /** @return detalhe da sugestão, ou texto vazio quando null */
    public String getDetalheSugestao(SugestaoRoupa sugestao)
    { /* este método devolve detalhe sugestao. */
        return sugestao == null ? "" : sugestao.obterDetalhe();
    }

    @Override
    public String toString()
    { /* este método devolve uma representação do objeto em texto. */
        return "Plataforma: " + utilizadores.size() + " utilizador(es), " + categorias.size() + " categoria(s), "
                + estilos.size() + " estilo(s), " + pecas.size() + " peça(s), " + contextos.size()
                + " contexto(s), " + sugestoes.size() + " sugestão(ões)";
    }
}
