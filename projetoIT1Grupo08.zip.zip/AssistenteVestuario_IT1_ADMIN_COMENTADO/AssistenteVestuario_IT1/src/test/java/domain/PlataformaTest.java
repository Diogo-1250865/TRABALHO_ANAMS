package domain;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

class PlataformaTest
{
    private Plataforma plataforma;
    private Categoria camisas;
    private Categoria calcas;
    private Estilo casual;
    private Estilo formal;
    private ContextoUtilizacao trabalho;

    @BeforeEach
    void preparar()
    { /* este método prepara os dados necessários para o teste. */
        plataforma = new Plataforma();
        camisas = new Categoria("Camisas");
        calcas = new Categoria("Calças");
        casual = new Estilo("Casual");
        formal = new Estilo("Formal");
        trabalho = new ContextoUtilizacao("trabalho", "frio", "média");
    }

    private PecaVestuario registaPeca(String nome, Categoria c, Estilo e)
    { /* este método cria e regista uma peça de teste. */
        PecaVestuario p = plataforma.criarPeca(nome, c, e, "azul", "M", "", "");
        assertTrue(plataforma.registarPeca(p));
        return p;
    }

    // ---------- singleton e dados iniciais ----------

    @Test
    void getInstanceDevolveSempreAMesmaInstancia()
    { /* este método devolve instance devolve sempre amesma instancia. */
        assertSame(Plataforma.getInstance(), Plataforma.getInstance());
        assertNotSame(plataforma, Plataforma.getInstance());
    }

    @Test
    void dadosIniciaisDeCategoriasEEstilosCarregados()
    { /* este teste verifica: dados iniciais de categorias e estilos carregados. */
        assertFalse(plataforma.getCategorias().isEmpty());
        assertFalse(plataforma.getEstilos().isEmpty());
        assertTrue(plataforma.existeCategoria(new Categoria("calças")));
        assertTrue(plataforma.existeEstilo(new Estilo("CASUAL")));
    }

    @Test
    void listasDevolvidasSaoCopias()
    { /* este teste verifica: listas devolvidas são cópias. */
        int antes = plataforma.getCategorias().size();
        plataforma.getCategorias().clear();
        assertEquals(antes, plataforma.getCategorias().size());
    }

    // ---------- uc01 ----------

    @Test
    void emailDuplicadoNaoPodeSerRegistado()
    { /* este teste verifica: email duplicado não pode ser registado. */
        assertTrue(plataforma.registarUtilizador(new Utilizador("Ana", "ana@isep.pt", "segredo123")));
        assertFalse(plataforma.registarUtilizador(new Utilizador("Outra", "ANA@isep.pt", "segredo456")));
        assertTrue(plataforma.existeUtilizadorComEmail("ana@isep.pt"));
    }

    @Test
    void utilizadorInvalidoNaoERegistado()
    { /* este teste verifica: utilizador inválido não é registado. */
        assertFalse(plataforma.registarUtilizador(plataforma.criarUtilizador()));
        assertFalse(plataforma.registarUtilizador(null));
    }

    // ---------- uc02 / uc03 ----------

    @Test
    void categoriaDuplicadaOuInvalidaNaoERegistada()
    { /* este teste verifica: categoria duplicada ou inválida não é registada. */
        assertTrue(plataforma.registarCategoria(plataforma.criarCategoria("Meias")));
        assertFalse(plataforma.registarCategoria(plataforma.criarCategoria("meias")));
        assertFalse(plataforma.registarCategoria(plataforma.criarCategoria("  ")));
    }

    @Test
    void estiloDuplicadoOuInvalidoNaoERegistado()
    { /* este teste verifica: estilo duplicado ou inválido não é registado. */
        assertTrue(plataforma.registarEstilo(plataforma.criarEstilo("Boémio")));
        assertFalse(plataforma.registarEstilo(plataforma.criarEstilo("boémio")));
        assertFalse(plataforma.registarEstilo(plataforma.criarEstilo("")));
    }

    // ---------- uc04 ----------

    @Test
    void pecaComCategoriaInexistenteNaoERegistada()
    { /* este teste verifica: peça com categoria inexistente não é registada. */
        PecaVestuario p = plataforma.criarPeca("Vestido", new Categoria("Vestidos"), formal, "preto", "S", "", "");
        assertFalse(plataforma.registarPeca(p));
    }

    @Test
    void pecaDuplicadaNaoERegistada()
    { /* este teste verifica: peça duplicada não é registada. */
        registaPeca("Camisa oxford", camisas, casual);
        PecaVestuario repetida = plataforma.criarPeca("camisa OXFORD", camisas, casual, "azul", "M", "", "");
        assertFalse(plataforma.registarPeca(repetida));
        assertEquals(1, plataforma.getPecas().size());
    }

    // ---------- uc05 ----------

    @Test
    void contextoDuplicadoOuInvalidoNaoERegistado()
    { /* este teste verifica: contexto duplicado ou inválido não é registado. */
        assertTrue(plataforma.registarContexto(new ContextoUtilizacao("trabalho", "frio", "média")));
        assertFalse(plataforma.registarContexto(new ContextoUtilizacao("Trabalho", "FRIO", "Média")));
        assertFalse(plataforma.registarContexto(new ContextoUtilizacao("trabalho", "", "média")));
        assertTrue(plataforma.registarContexto(new ContextoUtilizacao("trabalho", "calor", "média")));
    }

    // ---------- uc06 ----------

    @Test
    void categoriasDisponiveisSoIncluemCategoriasComPecasDoEstilo()
    { /* este teste verifica: categorias disponíveis só incluem categorias com peças do estilo. */
        registaPeca("Camisa oxford", camisas, casual);
        registaPeca("Calças de bolso", calcas, formal);

        List<Categoria> disponiveis = plataforma.getCategoriasDisponiveis(trabalho, casual);
        assertEquals(List.of(camisas), disponiveis);
    }

    @Test
    void sugestaoTemUmaPecaPorCategoriaEIndicaCategoriasSemPeca()
    { /* este teste verifica: sugestão tem uma peça por categoria e indica categorias sem peça. */
        PecaVestuario camisa = registaPeca("Camisa oxford", camisas, casual);

        SugestaoRoupa s = plataforma.criarSugestao(List.of(camisas, calcas), trabalho, casual);

        assertEquals(List.of(camisa), s.getPecas());
        assertEquals(List.of(calcas), s.getCategoriasSemPeca());
        assertTrue(s.valida());
        assertTrue(plataforma.registarSugestao(s));
        assertEquals(1, plataforma.getHistoricoSugestoes().size());
    }

    @Test
    void sugestaoSemNenhumaPecaNaoERegistada()
    { /* este teste verifica: sugestão sem nenhuma peça não é registada. */
        SugestaoRoupa s = plataforma.criarSugestao(List.of(camisas), trabalho, casual);
        assertFalse(s.valida());
        assertFalse(plataforma.registarSugestao(s));
        assertTrue(plataforma.getHistoricoSugestoes().isEmpty());
    }

    @Test
    void sugestaoNaoAceitaDuasPecasDaMesmaCategoria()
    { /* este teste verifica: sugestão não aceita duas peças da mesma categoria. */
        PecaVestuario a = registaPeca("Camisa A", camisas, casual);
        PecaVestuario b = registaPeca("Camisa B", camisas, casual);
        SugestaoRoupa s = new SugestaoRoupa(trabalho, casual, List.of(camisas));
        s.addPeca(a);
        s.addPeca(b);
        assertFalse(s.valida());
    }

    // ---------- uc07 ----------

    @Test
    void avaliacaoBaixaFazComQueOutraPecaSejaPreferidaNaProximaSugestao()
    { /* este teste verifica: avaliação baixa faz com que outra peça seja preferida na próxima sugestão. */
        PecaVestuario a = registaPeca("Camisa A", camisas, casual);
        PecaVestuario b = registaPeca("Camisa B", camisas, casual);

        SugestaoRoupa primeira = plataforma.criarSugestao(List.of(camisas), trabalho, casual);
        assertEquals(List.of(a), primeira.getPecas(), "Sem avaliações vence a primeira registada");
        plataforma.registarSugestao(primeira);
        assertTrue(plataforma.registarAvaliacao(primeira, plataforma.criarAvaliacao(1, "não gostei")));

        SugestaoRoupa segunda = plataforma.criarSugestao(List.of(camisas), trabalho, casual);
        assertEquals(List.of(b), segunda.getPecas());
    }

    @Test
    void sugestaoSoPodeSerAvaliadaUmaVezEComPontuacaoValida()
    { /* este teste verifica: sugestão só pode ser avaliada uma vez e com pontuacao valida. */
        registaPeca("Camisa A", camisas, casual);
        SugestaoRoupa s = plataforma.criarSugestao(List.of(camisas), trabalho, casual);
        plataforma.registarSugestao(s);

        assertFalse(plataforma.registarAvaliacao(s, plataforma.criarAvaliacao(0, "")));
        assertFalse(plataforma.registarAvaliacao(s, plataforma.criarAvaliacao(6, "")));
        assertFalse(s.isAvaliada());

        assertTrue(plataforma.registarAvaliacao(s, plataforma.criarAvaliacao(5, "ótimo")));
        assertTrue(s.isAvaliada());
        assertFalse(plataforma.registarAvaliacao(s, plataforma.criarAvaliacao(4, "outra vez")));
        assertEquals(5, s.getAvaliacao().getPontuacao());
    }

    @Test
    void sugestaoNaoRegistadaNaoPodeSerAvaliada()
    { /* este teste verifica: sugestão não registada não pode ser avaliada. */
        registaPeca("Camisa A", camisas, casual);
        SugestaoRoupa s = plataforma.criarSugestao(List.of(camisas), trabalho, casual);
        assertFalse(plataforma.registarAvaliacao(s, plataforma.criarAvaliacao(3, "")));
    }

    // ---------- uc08 ----------

    @Test
    void detalheMostraAAvaliacaoOuQueAindaNaoFoiAvaliada()
    { /* este teste verifica: detalhe mostra a avaliação ou que ainda não foi avaliada. */
        registaPeca("Camisa A", camisas, casual);
        SugestaoRoupa s = plataforma.criarSugestao(List.of(camisas), trabalho, casual);
        plataforma.registarSugestao(s);

        assertTrue(plataforma.getDetalheSugestao(s).contains("ainda não avaliada"));
        plataforma.registarAvaliacao(s, plataforma.criarAvaliacao(4, "bom"));
        assertTrue(plataforma.getDetalheSugestao(s).contains("4/5"));
    }

    // ---------- cobertura adicional: operações completas e isolamento ----------

    @Test
    void categoriaPodeSerEditadaERemovidaComReatribuicao()
    { /* este teste verifica: categoria pode ser editada e removida com reatribuição. */
        Categoria extra = plataforma.criarCategoria("Blazers");
        assertTrue(plataforma.registarCategoria(extra));
        PecaVestuario p = plataforma.criarPeca("Blazer", extra, formal, "preto", "M", "", "");
        assertTrue(plataforma.registarPeca(p));

        assertTrue(plataforma.editarCategoria(extra, "Fatos"));
        assertEquals("Fatos", extra.getNome());
        assertFalse(plataforma.removerCategoria(extra, null));
        assertTrue(plataforma.removerCategoria(extra, camisas));
        assertEquals(camisas, p.getCategoria());
    }

    @Test
    void estiloPodeSerEditadoERemovidoComReatribuicao()
    { /* este teste verifica: estilo pode ser editado e removido com reatribuição. */
        Estilo extra = plataforma.criarEstilo("Smart Casual");
        assertTrue(plataforma.registarEstilo(extra));
        PecaVestuario p = plataforma.criarPeca("Camisa", camisas, extra, "azul", "M", "", "");
        assertTrue(plataforma.registarPeca(p));

        assertTrue(plataforma.editarEstilo(extra, "Business Casual"));
        assertEquals("Business Casual", extra.getNome());
        assertFalse(plataforma.removerEstilo(extra, null));
        assertTrue(plataforma.removerEstilo(extra, casual));
        assertEquals(casual, p.getEstilo());
    }

    @Test
    void contextoPodeSerEditadoERemovidoSemApagarHistorico()
    { /* este teste verifica: contexto pode ser editado e removido sem apagar histórico. */
        assertTrue(plataforma.registarContexto(trabalho));
        registaPeca("Camisa A", camisas, casual);
        SugestaoRoupa s = plataforma.criarSugestao(List.of(camisas), trabalho, casual);
        assertTrue(plataforma.registarSugestao(s));

        assertTrue(plataforma.editarContexto(trabalho, "aulas", "frio", "média"));
        assertEquals("trabalho", s.getContexto().getOcasiao());
        assertTrue(plataforma.removerContexto(trabalho));
        assertEquals(1, plataforma.getHistoricoSugestoes().size());
    }

    @Test
    void trocaParcialSubstituiAPecaDaCategoria()
    { /* este teste verifica: troca parcial substitui a peça da categoria. */
        PecaVestuario a = registaPeca("Camisa A", camisas, casual);
        PecaVestuario b = registaPeca("Camisa B", camisas, casual);
        SugestaoRoupa s = plataforma.criarSugestao(List.of(camisas), trabalho, casual);
        assertEquals(a, s.getPecaDaCategoria(camisas));
        assertTrue(plataforma.trocarPecaSugestao(s, camisas));
        assertEquals(b, s.getPecaDaCategoria(camisas));
    }

    @Test
    void dadosDeDoisUtilizadoresFicamIsolados()
    { /* este teste verifica: dados de dois utilizadores ficam isolados. */
        Utilizador ana = new Utilizador("Ana", "ana@isep.pt", "segredo123");
        Utilizador joao = new Utilizador("João", "joao@isep.pt", "segredo456");
        assertTrue(plataforma.registarUtilizador(ana));
        registaPeca("Camisa Ana", camisas, casual);
        assertEquals(1, plataforma.getPecas().size());

        assertTrue(plataforma.registarUtilizador(joao));
        assertTrue(plataforma.getPecas().isEmpty());
        assertTrue(plataforma.getHistoricoSugestoes().isEmpty());

        assertTrue(plataforma.autenticar("ana@isep.pt", "segredo123"));
        assertEquals(1, plataforma.getPecas().size());
    }

}
