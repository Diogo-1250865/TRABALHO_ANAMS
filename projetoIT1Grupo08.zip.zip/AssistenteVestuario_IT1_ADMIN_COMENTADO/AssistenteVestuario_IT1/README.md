# Assistente Digital de Vestuário — Iteração 1

Projeto Java 17/Maven com implementação dos UC01–UC08.

## Casos de uso implementados

- **UC01 – Registar Utilizador**: validação, email único, password protegida com SHA-256 com salt individual e sessão automática após registo.
- **UC02 – Gerir Categorias**: adicionar, editar e remover; se existirem peças associadas, é obrigatória a reatribuição para outra categoria.
- **UC03 – Gerir Estilos**: adicionar, editar e remover; se existirem peças associadas, é obrigatória a reatribuição para outro estilo.
- **UC04 – Registar Peça de Vestuário**: registo por utilizador autenticado, validação de categoria/estilo e fotografia.
- **UC05 – Gerir Contextos de Utilização**: criar, editar e eliminar contextos do utilizador.
- **UC06 – Sugerir Roupa**: sugestão por contexto, estilo e categorias; suporta troca parcial de uma peça por outra alternativa da mesma categoria.
- **UC07 – Avaliar Sugestão**: pontuação 1–5 e comentário; a avaliação influencia sugestões futuras.
- **UC08 – Consultar Histórico**: histórico e avaliações isolados por utilizador.

## Utilizadores, administrador e sessão

O utilizador acabado de registar fica automaticamente com sessão iniciada como **UTILIZADOR**. Um utilizador normal não pode gerir categorias nem estilos. As opções UC02 e UC03 só aparecem no menu quando a sessão pertence a um **ADMINISTRADOR**, e o acesso também é validado no `Main`, na UI e no Controller.

Para demonstração da Iteração 1 é criado automaticamente um administrador inicial:

- email: `admin@vestuario.pt`
- palavra-passe: `Admin1234!`

O menu permite iniciar sessão/trocar utilizador e terminar sessão. Os UC04–UC08 trabalham apenas sobre os dados do utilizador atual.

## Regra simples de contexto na IT1

Como o modelo da peça não possui ainda atributos térmicos/meteorológicos, o campo `clima` é registado e preservado no histórico, mas não filtra diretamente peças. O nível de formalidade é usado numa regra simples:

- `alta/formal` → estilos `Formal` ou `Elegante`;
- `baixa/informal` → estilos `Casual` ou `Desportivo`;
- `média` ou outro valor → não restringe o estilo.

Esta regra está concentrada em `ContextoUtilizacao.compativelCom(Estilo)` e pode ser facilmente substituída quando o cliente/docente validar uma regra diferente.

## Executar no IntelliJ

1. Abrir a pasta que contém `pom.xml` e `src`.
2. Confirmar JDK 17 (ou superior compatível).
3. Deixar o IntelliJ carregar o projeto Maven.
4. Executar `Main.java`.
5. Para testes, executar `src/test/java` com JUnit 5.

## Verificações realizadas

- Compilação de todo `src/main/java` com `javac` sem erros.
- Smoke test de domínio cobrindo CRUD de categorias/estilos/contextos, isolamento entre utilizadores, autenticação, sugestão, troca parcial, avaliação e histórico.
- Execução automática do fluxo principal: registar utilizador → registar peça → criar contexto → sugerir roupa → avaliar → consultar histórico.

## Persistência / memória permanente

A aplicação guarda automaticamente o seu estado em `dados/assistente-vestuario.dat`.
Assim, os dados continuam disponíveis depois de fechar e voltar a abrir o programa, incluindo:

- utilizadores e hashes/salts das palavras-passe;
- categorias e estilos criados/editados;
- peças de vestuário;
- contextos de utilização;
- sugestões e respetivas avaliações/histórico.

A sessão (utilizador atualmente autenticado) **não** é mantida por segurança. Depois de reiniciar a aplicação é necessário usar a opção **9. Iniciar sessão / trocar utilizador**.

O ficheiro é atualizado automaticamente sempre que uma operação altera dados e é novamente guardado ao sair. Para repor a aplicação do zero, com as categorias e estilos iniciais, basta fechar o programa e apagar a pasta `dados` (ou apenas o ficheiro `dados/assistente-vestuario.dat`).
