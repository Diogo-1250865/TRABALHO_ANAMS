package domain;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class PecaVestuarioTest
{
    private final Categoria camisas = new Categoria("Camisas");
    private final Estilo casual = new Estilo("Casual");

    private PecaVestuario peca(String nome, String foto)
    { /* este método cria uma peça de teste com a fotografia indicada. */
        return new PecaVestuario(nome, camisas, casual, "azul", "M", "Zara", foto);
    }

    @Test
    void pecaCompletaEValida()
    { /* este teste verifica: peça completa é válida. */
        assertTrue(peca("Camisa oxford", "camisa.jpg").valida());
    }

    @Test
    void fotografiaEOpcional()
    { /* este teste verifica: fotografia é opcional. */
        assertTrue(peca("Camisa oxford", "").valida());
        assertTrue(peca("Camisa oxford", null).valida());
    }

    @Test
    void formatosDeFotografiaSuportadosSemDistinguirMaiusculas()
    { /* este teste verifica: formatos de fotografia suportados sem distinguir maiúsculas. */
        assertTrue(peca("A", "a.JPG").valida());
        assertTrue(peca("A", "a.jpeg").valida());
        assertTrue(peca("A", "a.PNG").valida());
        assertFalse(peca("A", "a.gif").valida());
        assertFalse(peca("A", "a.pdf").valida());
    }

    @Test
    void camposObrigatoriosEmFaltaSaoRejeitados()
    { /* este teste verifica: campos obrigatórios em falta são rejeitados. */
        assertFalse(new PecaVestuario("", camisas, casual, "azul", "M", "", "").valida());
        assertFalse(new PecaVestuario("A", null, casual, "azul", "M", "", "").valida());
        assertFalse(new PecaVestuario("A", camisas, null, "azul", "M", "", "").valida());
        assertFalse(new PecaVestuario("A", camisas, casual, " ", "M", "", "").valida());
        assertFalse(new PecaVestuario("A", camisas, casual, "azul", "", "", "").valida());
    }

    @Test
    void pecasIguaisNaoDistinguemMaiusculas()
    { /* este teste verifica: peças iguais não distinguem maiúsculas. */
        assertEquals(peca("Camisa Oxford", ""), peca("camisa oxford", ""));
    }
}
