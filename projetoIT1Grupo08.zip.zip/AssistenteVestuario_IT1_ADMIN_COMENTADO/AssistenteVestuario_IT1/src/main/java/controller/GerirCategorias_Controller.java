package controller;

import domain.Categoria;
import domain.Plataforma;

import java.util.List;

/**
 * controlador grasp do uc02 - gerir categorias.
 */
public class GerirCategorias_Controller {
    private final Plataforma plataforma;
    private Categoria categoria;

    /**
     * @param plataforma repositório do domínio
     */
    public GerirCategorias_Controller(Plataforma plataforma) { /* este método prepara uma nova instância desta classe. */
        this.plataforma = plataforma;
    }

    public boolean temPermissaoAdministrador() { /* este método verifica se o utilizador atual tem permissão de administrador. */
        return plataforma.utilizadorAtualEhAdministrador();
    }// só o administrador pode alterar as categorias

    /**
     * @return categorias existentes
     */
    public List<Categoria> getCategorias() { /* este método devolve categorias. */
        return plataforma.getCategorias(); // devolve as categorias existentes
    }

    /**
     * prepara uma nova categoria.
     */
    public void novaCategoria(String nome) { /* este método cria ou prepara categoria. */
        categoria = temPermissaoAdministrador() ? plataforma.criarCategoria(nome) : null;
    }

    /**
     * seleciona uma categoria existente para editar/remover.
     */
    public void selecionarCategoria(Categoria categoria) { /* este método seleciona categoria. */
        this.categoria = categoria;
    }

    /**
     * @return categoria atualmente selecionada
     */
    public Categoria getCategoria() { /* este método devolve categoria. */
        return categoria;
    }

    /**
     * @return número de peças associadas à categoria selecionada
     */
    public int contarPecasAssociadas() { /* este método conta pecas associadas. */
        return plataforma.contarPecasDaCategoria(categoria); // conta as peças associadas à categoria selecionada
    }

    /**
     * valida uma nova categoria.
     */
    public String validar() { /* este método valida a categoria em criação. */
        if (!temPermissaoAdministrador()) return "Acesso reservado ao administrador.";// só o administrador tem acesso
        if (categoria == null || !categoria.valida()) return "Dados em falta ou inválidos (o nome é obrigatório).";// o nome é obrigatório
        if (plataforma.existeCategoria(categoria)) return "Já existe uma categoria com esse nome.";// não pode existir outra categoria igual
        return null; // null significa que não há erro
    }

    /**
     * valida um novo nome para edição.
     */
    public String validarNovoNome(String novoNome) { /* este método valida novo nome. */
        if (!temPermissaoAdministrador()) return "Acesso reservado ao administrador."; // só o administrador pode editar o nome de uma categoria
        Categoria candidata = plataforma.criarCategoria(novoNome);
        if (!candidata.valida()) return "Dados em falta ou inválidos (o nome é obrigatório).";
        for (Categoria c : plataforma.getCategorias()) {
            if (c != categoria && c.equals(candidata)) return "Já existe uma categoria com esse nome.";
        }
        return null;
    }

    /**
     * @return dados da categoria em criação/selecionada
     */
    public String obterDados() { /* este método devolve dados. */
        return categoria == null ? "" : categoria.obterDados();
    }

    /**
     * @return true se a nova categoria foi registada
     */
    public boolean registarCategoria() { /* este método regista categoria. */
        return temPermissaoAdministrador() && plataforma.registarCategoria(categoria);
    }

    /**
     * @return true se a categoria foi editada
     */
    public boolean editarCategoria(String novoNome) { /* este método edita categoria. */
        return temPermissaoAdministrador() && plataforma.editarCategoria(categoria, novoNome);
    }

    /**
     * remove a categoria, reatribuindo peças quando necessário.
     *
     * @param destino categoria de destino, ou null se não existem peças associadas
     */
    public boolean removerCategoria(Categoria destino) { /* este método remove categoria. */
        return temPermissaoAdministrador() && plataforma.removerCategoria(categoria, destino);
    }
}
