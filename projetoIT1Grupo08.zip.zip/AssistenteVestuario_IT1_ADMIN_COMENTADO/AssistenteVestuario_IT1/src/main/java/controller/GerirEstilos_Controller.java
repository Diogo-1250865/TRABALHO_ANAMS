package controller;

import domain.Estilo;
import domain.Plataforma;

import java.util.List;

/** controlador grasp do uc03 - gerir estilos. */
public class GerirEstilos_Controller
{
    private final Plataforma plataforma;
    private Estilo estilo;

    /** @param plataforma repositório do domínio */
    public GerirEstilos_Controller(Plataforma plataforma) { /* este método prepara uma nova instância desta classe. */ this.plataforma = plataforma; }

    public boolean temPermissaoAdministrador()
    { /* este método verifica se o utilizador atual tem permissão de administrador. */
        return plataforma.utilizadorAtualEhAdministrador();
    } // só o administrador pode alterar os estilos

    /** @return estilos existentes */
    public List<Estilo> getEstilos() { /* este método devolve estilos. */ return plataforma.getEstilos(); }

    /** prepara um novo estilo. */
    public void novoEstilo(String nome) { /* este método cria ou prepara estilo. */ estilo = temPermissaoAdministrador() ? plataforma.criarEstilo(nome) : null; }

    /** seleciona um estilo existente. */
    public void selecionarEstilo(Estilo estilo) { /* este método seleciona estilo. */ this.estilo = estilo; }

    /** @return estilo selecionado */
    public Estilo getEstilo() { /* este método devolve estilo. */ return estilo; }

    /** @return número de peças associadas ao estilo selecionado */
    public int contarPecasAssociadas() { /* este método conta pecas associadas. */ return plataforma.contarPecasDoEstilo(estilo); }

    /** valida um estilo novo. */
    public String validar()
    { /* este método valida o estilo em criação. */
        if (!temPermissaoAdministrador()) return "Acesso reservado ao administrador.";
        if (estilo == null || !estilo.valida()) return "Dados em falta ou inválidos (o nome é obrigatório).";
        if (plataforma.existeEstilo(estilo)) return "Já existe um estilo com esse nome.";
        return null;
    }

    /** valida um nome novo para edição. */
    public String validarNovoNome(String novoNome)
    { /* este método valida novo nome. */
        if (!temPermissaoAdministrador()) return "Acesso reservado ao administrador.";
        Estilo candidato = plataforma.criarEstilo(novoNome);
        if (!candidato.valida()) return "Dados em falta ou inválidos (o nome é obrigatório).";
        for (Estilo e : plataforma.getEstilos())
        {
            if (e != estilo && e.equals(candidato)) return "Já existe um estilo com esse nome.";
        }
        return null;
    }

    /** @return dados do estilo */
    public String obterDados() { /* este método devolve dados. */ return estilo == null ? "" : estilo.obterDados(); }
    /** @return true se registado */
    public boolean registarEstilo() { /* este método regista estilo. */ return temPermissaoAdministrador() && plataforma.registarEstilo(estilo); }
    /** @return true se editado */
    public boolean editarEstilo(String novoNome) { /* este método edita estilo. */ return temPermissaoAdministrador() && plataforma.editarEstilo(estilo, novoNome); }
    /** @return true se removido */
    public boolean removerEstilo(Estilo destino) { /* este método remove estilo. */ return temPermissaoAdministrador() && plataforma.removerEstilo(estilo, destino); }
}
