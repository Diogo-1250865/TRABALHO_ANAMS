package controller;

import domain.Plataforma;
import domain.Utilizador;

/**
 * controlador do uc01 - registar utilizador (grasp controller).
 * mantém o utilizador em criação até à confirmação e só então o entrega à plataforma.
 *
 * @author diogo
 */
public class RegistarUtilizador_Controller {
    private final Plataforma plataforma;
    private Utilizador utilizador;

    public RegistarUtilizador_Controller(Plataforma plataforma) { /* este método prepara uma nova instância desta classe. */
        this.plataforma = plataforma;
    }

    public void novoUtilizador() { /* este método cria ou prepara utilizador. */
        this.utilizador = plataforma.criarUtilizador();
    }// pede para criar um novo utilizador

    public void setDados(String nome, String email, String palavraPasse) { /* este método atualiza dados. */
        this.utilizador.setNome(nome);
        this.utilizador.setEmail(email);
        this.utilizador.setPalavraPasse(palavraPasse);
    }

    /**
     * valida os dados introduzidos.
     *
     * @return mensagem de erro, ou null se os dados são válidos
     */
    public String validar() { /* este método valida o utilizador em criação. */
        if (!utilizador.valida()) {
            return "Dados em falta ou inválidos (nome obrigatório, email com formato válido e palavra-passe com pelo menos "
                    + Utilizador.PALAVRA_PASSE_MIN_LENGTH + " caracteres).";
        }
        if (plataforma.existeUtilizadorComEmail(utilizador.getEmail())) {
            return "O email introduzido já está registado.";
        }
        return null;
    }

    public String obterDados() { /* este método devolve dados. */
        return utilizador.obterDados();
    }

    public boolean registarUtilizador() { /* este método regista utilizador. */
        return plataforma.registarUtilizador(utilizador);
    }// pede à plataforma para registar o utilizador
}
