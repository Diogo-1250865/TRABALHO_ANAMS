package domain;

import java.io.Serializable;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Arrays;

/**
 * utilizador registado na plataforma (uc01 - registar utilizador).
 * a palavra-passe nunca é guardada em texto simples. é guardado apenas o hash sha-256
 * juntamente com um salt aleatório individual de 16 bytes, permitindo autenticação sem expor a palavra-passe.
 *
 * @author diogo
 */
public class Utilizador implements Serializable {                        // permite guardar o objeto em ficheiro (persistência)
    private static final long serialVersionUID = 1L;                    // identifica a versão da classe guardada em ficheiro
    private static final String STRING_POR_OMISSAO = "a definir";
    private static final int TAMANHO_SALT_BYTES = 16;

    /**
     * comprimento mínimo da palavra-passe (regra de it1).
     */
    public static final int PALAVRA_PASSE_MIN_LENGTH = 8;

    private String nome;
    private String email;
    private byte[] palavraPasseSalt;
    private byte[] palavraPasseHash;
    private boolean palavraPasseValida;
    private TipoUtilizador tipo;

    /**
     * cria um utilizador ainda por preencher.
     */
    public Utilizador() { /* este método prepara uma nova instância desta classe. */
        this.nome = STRING_POR_OMISSAO;
        this.email = STRING_POR_OMISSAO;
        this.palavraPasseSalt = null;
        this.palavraPasseHash = null;
        this.palavraPasseValida = false;
        this.tipo = TipoUtilizador.UTILIZADOR;
    }

    /**
     * cria um utilizador com os dados recebidos.
     *
     * @param nome         nome
     * @param email        email único
     * @param palavraPasse palavra-passe em texto simples (não é armazenada)
     */
    public Utilizador(String nome, String email, String palavraPasse) { /* este método prepara uma nova instância desta classe. */
        this(nome, email, palavraPasse, TipoUtilizador.UTILIZADOR);
    }

    public Utilizador(String nome, String email, String palavraPasse, TipoUtilizador tipo) { /* este método prepara uma nova instância desta classe. */
        setNome(nome);
        setEmail(email);
        setPalavraPasse(palavraPasse);
        this.tipo = tipo == null ? TipoUtilizador.UTILIZADOR : tipo;  // se o tipo for null, assume utilizador normal em vez de
    }                                                                 // falhar

    /**
     * @return nome do utilizador
     */
    public String getNome() { /* este método devolve nome. */
        return nome;
    }

    /**
     * @param nome novo nome
     */
    public void setNome(String nome) { /* este método atualiza nome. */
        this.nome = nome;
    }

    /**
     * @return email do utilizador
     */
    public String getEmail() { /* este método devolve email. */
        return email;
    }

    /**
     * @param email novo email
     */
    public void setEmail(String email) { /* este método atualiza email. */
        this.email = email;
    }

    /**
     * define a palavra-passe, guardando apenas sha-256(salt + palavra-passe).
     *
     * @param palavraPasse palavra-passe em texto simples
     */
    public void setPalavraPasse(String palavraPasse) { /* este método atualiza palavra passe. */
        if (palavraPasse == null) {                     // se a palavra-passe for null, apaga os dados guardados e marca-a como inválida
            palavraPasseSalt = null;                    // apaga o salt
            palavraPasseHash = null;                    // apaga o hash
            palavraPasseValida = false;
            return;
        }

        palavraPasseValida = palavraPasse.length() >= PALAVRA_PASSE_MIN_LENGTH;
        palavraPasseSalt = new byte[TAMANHO_SALT_BYTES];
        new SecureRandom().nextBytes(palavraPasseSalt);
        palavraPasseHash = derivarChave(palavraPasse, palavraPasseSalt);
    }

    /**
     * verifica uma palavra-passe sem a armazenar.
     *
     * @param palavraPasse palavra-passe candidata
     * @return true quando corresponde ao hash guardado
     */
    public boolean autentica(String palavraPasse) { /* este método verifica as credenciais e autentica o utilizador. */
        if (palavraPasse == null || palavraPasseSalt == null || palavraPasseHash == null) {
            return false;
        }
        byte[] candidata = derivarChave(palavraPasse, palavraPasseSalt);
        return Arrays.equals(palavraPasseHash, candidata);
    }

    /**
     * validação local do utilizador.
     *
     * @return true se nome, email e palavra-passe são válidos
     */
    public boolean valida() { /* este método valida os dados do objeto. */
        return validaNome() && validaEmail() && palavraPasseValida;
    }

    private boolean validaNome() { /* este método valida nome. */
        return nome != null && !nome.isBlank() && !nome.equals(STRING_POR_OMISSAO);
    }

    private boolean validaEmail() { /* este método valida email. */
        if (email == null || email.isBlank()) {
            return false;
        }
        int posArroba = email.indexOf('@');
        int posPonto = email.lastIndexOf('.');
        return posArroba > 0 && posArroba == email.lastIndexOf('@') && posPonto > posArroba + 1 && posPonto < email.length() - 1 && !email.contains(" ");
    }

    /**
     * compara emails sem distinguir maiúsculas/minúsculas.
     *
     * @param outroEmail email a comparar
     * @return true se coincide
     */
    public boolean temEmail(String outroEmail) { /* este método verifica se o email recebido corresponde ao email guardado. */
        return email != null && outroEmail != null && email.trim().equalsIgnoreCase(outroEmail.trim()); // compara o email recebido com o email guardado,
    }                                                                                                   // ignorando maiúsculas/minúsculas e espaços nas pontas
                                                                                                        // (usado no início de sessão e na verificação de email repetido)

    public TipoUtilizador getTipo() { /* este método devolve tipo. */
        return tipo == null ? TipoUtilizador.UTILIZADOR : tipo;
    }

    public boolean isAdministrador() { /* este método indica se administrador. */
        return getTipo() == TipoUtilizador.ADMINISTRADOR;
    } // devolve true se o tipo do utilizador for administrador

    /**
     * @return dados seguros para apresentação
     */
    public String obterDados() { /* este método devolve dados. */
        return "Nome: " + nome + " | Email: " + email;
    }

    @Override
    public String toString() { /* este método devolve uma representação do objeto em texto. */
        return obterDados();
    }

    private static byte[] derivarChave(String texto, byte[] salt) { /* este método calcula o hash sha-256 do salt seguido da palavra-passe. */
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);
            return md.digest(texto.getBytes(StandardCharsets.UTF_8));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 não disponível", e);
        }
    }
}
