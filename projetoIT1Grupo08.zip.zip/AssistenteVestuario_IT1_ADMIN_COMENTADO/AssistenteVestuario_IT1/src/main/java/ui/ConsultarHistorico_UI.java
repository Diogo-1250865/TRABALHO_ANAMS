package ui;

import controller.ConsultarHistorico_Controller;
import domain.Plataforma;
import domain.SugestaoRoupa;
import utils.Utils;

import java.util.List;

/** interface de consola do uc08 - consultar histórico de sugestões e avaliações. */
public class ConsultarHistorico_UI
{
    private final ConsultarHistorico_Controller controller;

    public ConsultarHistorico_UI(Plataforma plataforma)
    { /* este método prepara uma nova instância desta classe. */
        controller = new ConsultarHistorico_Controller(plataforma);
    }

    /** executa a consulta repetida do histórico. */
    public void run()
    { /* este método executa o fluxo principal deste caso de uso. */
        System.out.println("\n=== Histórico de Sugestões e Avaliações ===");
        if (!controller.temUtilizadorAtivo())
        {
            System.out.println("É necessário iniciar sessão com um utilizador.");
            return;
        }

        List<SugestaoRoupa> historico = controller.getHistoricoSugestoes();
        if (historico.isEmpty())
        {
            System.out.println("Não tem sugestões registadas.");
            return;
        }

        SugestaoRoupa selecionada;
        do
        {
            selecionada = Utils.apresentaESeleciona(historico,
                    "Sugestões registadas (selecione uma para ver o detalhe):", "Voltar");
            if (selecionada != null)
                System.out.println("\n" + controller.getDetalheSugestao(selecionada));
        } while (selecionada != null);
    }
}
