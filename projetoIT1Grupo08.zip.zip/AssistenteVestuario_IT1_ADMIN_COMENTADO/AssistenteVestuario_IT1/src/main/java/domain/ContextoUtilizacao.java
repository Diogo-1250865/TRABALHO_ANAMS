package domain;

import java.io.Serializable;

import java.util.Locale;
import java.util.Objects;

/**
 * contexto de utilização do vestuário: ocasião, clima e formalidade
 * (uc05 - gerir contextos de utilização).
 */
public class ContextoUtilizacao implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final String STRING_POR_OMISSAO = "a definir";

    private String ocasiao;
    private String clima;
    private String formalidade;
    private Utilizador proprietario;

    /**
     * cria um contexto por preencher.
     */
    public ContextoUtilizacao() { /* este método prepara uma nova instância desta classe. */
        this(null, STRING_POR_OMISSAO, STRING_POR_OMISSAO, STRING_POR_OMISSAO);
    }

    /**
     * cria um contexto sem proprietário explícito (compatibilidade com testes).
     */
    public ContextoUtilizacao(String ocasiao, String clima, String formalidade) { /* este método prepara uma nova instância desta classe. */
        this(null, ocasiao, clima, formalidade);
    }

    /**
     * cria um contexto associado a um utilizador.
     *
     * @param proprietario utilizador dono do contexto
     * @param ocasiao      ocasião
     * @param clima        clima
     * @param formalidade  nível de formalidade
     */
    public ContextoUtilizacao(Utilizador proprietario, String ocasiao, String clima, String formalidade) { /* este método prepara uma nova instância desta classe. */
        this.proprietario = proprietario;
        setOcasiao(ocasiao);
        setClima(clima);
        setFormalidade(formalidade);
    }

    /**
     * @return proprietário ou null em objetos legados/testes
     */
    public Utilizador getProprietario() { /* este método devolve proprietario. */
        return proprietario;
    }

    /**
     * associa o contexto a um utilizador.
     */
    public void setProprietario(Utilizador proprietario) { /* este método atualiza proprietario. */
        this.proprietario = proprietario;
    }

    /**
     * @return ocasião
     */
    public String getOcasiao() { /* este método devolve ocasiao. */
        return ocasiao;
    }

    /**
     * @param ocasiao nova ocasião
     */
    public void setOcasiao(String ocasiao) { /* este método atualiza ocasiao. */
        this.ocasiao = ocasiao;
    }

    /**
     * @return clima
     */
    public String getClima() { /* este método devolve clima. */
        return clima;
    }

    /**
     * @param clima novo clima
     */
    public void setClima(String clima) { /* este método atualiza clima. */
        this.clima = clima;
    }

    /**
     * @return formalidade
     */
    public String getFormalidade() { /* este método devolve formalidade. */
        return formalidade;
    }

    /**
     * @param formalidade nova formalidade
     */
    public void setFormalidade(String formalidade) { /* este método atualiza formalidade. */
        this.formalidade = formalidade;
    }

    /**
     * @return true se todos os dados obrigatórios estão preenchidos
     */
    public boolean valida() { /* este método valida os dados do objeto. */
        return preenchido(ocasiao) && preenchido(clima) && preenchido(formalidade);
    }

    /**
     * regra simples de it1 para tornar o contexto efetivamente relevante na sugestão.
     * formalidade alta aceita estilos formal/elegante; baixa aceita casual/desportivo;
     * média (ou valores não reconhecidos) não restringe o estilo.
     *
     * @param estilo estilo pretendido
     * @return true se o estilo é coerente com o nível de formalidade
     */
    public boolean compativelCom(Estilo estilo) { /* este método verifica se o estilo é compatível com a formalidade. */
        if (estilo == null) {
            return false;
        }
        String f = norm(formalidade);
        String e = norm(estilo.getNome());
        if (f.equals("alta") || f.equals("alto") || f.equals("formal")) {
            return e.equals("formal") || e.equals("elegante");
        }
        if (f.equals("baixa") || f.equals("baixo") || f.equals("informal")) {
            return e.equals("casual") || e.equals("desportivo");
        }
        return true;
    }

    /**
     * @return cópia para preservar o contexto histórico de uma sugestão
     */
    public ContextoUtilizacao copia() { /* este método devolve uma cópia deste contexto. */
        return new ContextoUtilizacao(proprietario, ocasiao, clima, formalidade);
    }

    /**
     * @return texto para confirmação/apresentação
     */
    public String obterDados() { /* este método devolve dados. */
        return "Ocasião: " + ocasiao + " | Clima: " + clima + " | Formalidade: " + formalidade;
    }

    private static boolean preenchido(String texto) { /* este método verifica se o texto está preenchido. */
        return texto != null && !texto.isBlank() && !texto.equals(STRING_POR_OMISSAO);
    }

    private static String norm(String texto) { /* este método normaliza o texto para comparação. */
        return texto == null ? "" : texto.trim().toLowerCase(Locale.ROOT);
    }

    /**
     * dois contextos são iguais quando coincidem a ocasião, o clima e a formalidade
     * (sem distinguir maiúsculas; o proprietário não é comparado).
     */
    @Override
    public boolean equals(Object o) { /* este método compara este objeto com outro. */
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ContextoUtilizacao outro = (ContextoUtilizacao) o;
        return norm(ocasiao).equals(norm(outro.ocasiao))
                && norm(clima).equals(norm(outro.clima))
                && norm(formalidade).equals(norm(outro.formalidade));
    }

    @Override
    public int hashCode() { /* este método calcula o código hash do objeto. */
        return Objects.hash(norm(ocasiao), norm(clima), norm(formalidade));
    }

    @Override
    public String toString() { /* este método devolve uma representação do objeto em texto. */
        return ocasiao + " / " + clima + " / " + formalidade;
    }
}
