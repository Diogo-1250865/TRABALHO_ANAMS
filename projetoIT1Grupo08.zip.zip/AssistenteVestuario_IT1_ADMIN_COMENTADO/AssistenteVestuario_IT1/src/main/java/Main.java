import domain.Plataforma;
import ui.AvaliarSugestao_UI;
import ui.ConsultarHistorico_UI;
import ui.GerirCategorias_UI;
import ui.GerirContextos_UI;
import ui.GerirEstilos_UI;
import ui.RegistarPeca_UI;
import ui.RegistarUtilizador_UI;
import ui.SugerirRoupa_UI;
import utils.EntradaTerminadaException;
import utils.Utils;

/** classe de arranque do assistente digital de vestuário - iteração 1. */
public class Main
{
    public static void main(String[] args)
    { /* este método inicia a aplicação e controla o menu principal. */
        Plataforma plataforma = Plataforma.getInstance();
        try
        {
            String opcao;
            do
            {
                apresentaMenu(plataforma);
                opcao = Utils.readLineFromConsole("Escolha uma opção: ");
                try
                {
                    executa(opcao, plataforma);
                }
                catch (EntradaTerminadaException e)
                {
                    throw e;
                }
                catch (RuntimeException e)
                {
                    System.out.println("--> Ocorreu um erro inesperado: " + e.getMessage());
                }
            } while (!opcao.equals("0"));
            System.out.println("Até à próxima!");
        }
        catch (EntradaTerminadaException e)
        {
            System.out.println("\n" + e.getMessage() + " A terminar.");
        }
        finally
        {
            // esta gravação final ajuda a garantir que o estado fica guardado ao fechar o programa.
            plataforma.guardarDados();
            System.out.println("Dados guardados em: " + plataforma.getLocalizacaoFicheiroDados());
        }
    }

    private static void apresentaMenu(Plataforma plataforma)
    { /* este método apresenta menu. */
        System.out.println("\n###### ASSISTENTE DIGITAL DE VESTUÁRIO ######");
        if (plataforma.temUtilizadorAtivo())
        {
            String tipo = plataforma.utilizadorAtualEhAdministrador() ? "administrador" : "utilizador";
            System.out.println("Utilizador atual: " + plataforma.getUtilizadorAtual().getEmail() + " (" + tipo + ")");
        }
        else
        {
            System.out.println("Utilizador atual: nenhum");
        }

        System.out.println("1. Registar utilizador");
        if (plataforma.utilizadorAtualEhAdministrador())
        {
            System.out.println("2. Gerir categorias");
            System.out.println("3. Gerir estilos");
        }
        System.out.println("4. Registar peça de vestuário");
        System.out.println("5. Gerir contextos de utilização");
        System.out.println("6. Sugerir roupa");
        System.out.println("7. Avaliar sugestão");
        System.out.println("8. Consultar histórico de sugestões e avaliações");
        System.out.println("9. Iniciar sessão / trocar utilizador");
        System.out.println("10. Terminar sessão");
        System.out.println("0. Sair");
    }

    private static void executa(String opcao, Plataforma plataforma)
    { /* este método executa a opção escolhida no menu. */
        switch (opcao)
        {
            case "1" -> new RegistarUtilizador_UI(plataforma).run();
            case "2" -> executarGestaoCategorias(plataforma);
            case "3" -> executarGestaoEstilos(plataforma);
            case "4" -> new RegistarPeca_UI(plataforma).run();
            case "5" -> new GerirContextos_UI(plataforma).run();
            case "6" -> new SugerirRoupa_UI(plataforma).run();
            case "7" -> new AvaliarSugestao_UI(plataforma).run();
            case "8" -> new ConsultarHistorico_UI(plataforma).run();
            case "9" -> iniciarSessao(plataforma);
            case "10" -> {
                plataforma.terminarSessao();
                System.out.println("Sessão terminada.");
            }
            case "0" -> { }
            default -> System.out.println("Opção inválida.");
        }
    }

    private static void executarGestaoCategorias(Plataforma plataforma)
    { /* este método abre a gestão de categorias apenas para o administrador. */
        if (!plataforma.utilizadorAtualEhAdministrador())
        {
            System.out.println("Acesso reservado ao administrador.");
            return;
        }
        new GerirCategorias_UI(plataforma).run();
    }

    private static void executarGestaoEstilos(Plataforma plataforma)
    { /* este método abre a gestão de estilos apenas para o administrador. */
        if (!plataforma.utilizadorAtualEhAdministrador())
        {
            System.out.println("Acesso reservado ao administrador.");
            return;
        }
        new GerirEstilos_UI(plataforma).run();
    }

    private static void iniciarSessao(Plataforma plataforma)
    { /* este método pede as credenciais e inicia a sessão do utilizador. */
        if (plataforma.getUtilizadores().isEmpty())
        {
            System.out.println("Ainda não existem utilizadores registados.");
            return;
        }
        String email = Utils.readLineFromConsole("Email: ");
        String palavraPasse = Utils.readLineFromConsole("Palavra-passe: ");
        System.out.println(plataforma.autenticar(email, palavraPasse)
                ? "Sessão iniciada com sucesso."
                : "Email ou palavra-passe inválidos.");
    }
}
