package ui;

import controller.SugerirRoupa_Controller;
import domain.Categoria;
import domain.ContextoUtilizacao;
import domain.Estilo;
import domain.Plataforma;
import domain.PecaVestuario;
import utils.Utils;

import java.util.ArrayList;
import java.util.List;

/** interface de consola do uc06 - sugerir roupa. */
public class SugerirRoupa_UI
{
    private final SugerirRoupa_Controller controller;

    public SugerirRoupa_UI(Plataforma plataforma)
    { /* este método prepara uma nova instância desta classe. */
        controller = new SugerirRoupa_Controller(plataforma);
    }

    /** executa sugestão, troca parcial e confirmação. */
    public void run()
    { /* este método executa o fluxo principal deste caso de uso. */
        System.out.println("\n=== Sugerir Roupa ===");
        if (!controller.temUtilizadorAtivo())
        {
            System.out.println("É necessário iniciar sessão com um utilizador.");
            return;
        }

        List<ContextoUtilizacao> contextos = controller.getContextos();
        if (contextos.isEmpty())
        {
            System.out.println("Não existem contextos de utilização registados. Registe um contexto primeiro.");
            return;
        }

        ContextoUtilizacao contexto = Utils.apresentaESeleciona(contextos,
                "Selecione o contexto de utilização (ocasião / clima / formalidade):");
        if (contexto == null) return;

        Estilo estilo = Utils.apresentaESeleciona(controller.getEstilos(), "Selecione o estilo pretendido:");
        if (estilo == null) return;

        List<Categoria> disponiveis = controller.getCategoriasDisponiveis(contexto, estilo);
        if (disponiveis.isEmpty())
        {
            if (!contexto.compativelCom(estilo))
                System.out.println("O estilo selecionado não é compatível com o nível de formalidade do contexto.");
            else
                System.out.println("Não tem peças disponíveis para este estilo em nenhuma categoria.");
            return;
        }

        List<Categoria> selecionadas = selecionaCategorias(disponiveis);
        if (selecionadas.isEmpty())
        {
            System.out.println("Operação cancelada.");
            return;
        }

        controller.determinarSugestao(selecionadas);
        String erro = controller.validar();
        if (erro != null)
        {
            System.out.println("--> " + erro);
            return;
        }

        System.out.println("\nSugestão:\n" + controller.obterSugestao());
        gerirTrocasParciais();

        if (Utils.confirma("Confirma a sugestão final? (S/N)"))
        {
            System.out.println(controller.registarSugestao()
                    ? "Sugestão registada com sucesso. Pode avaliá-la mais tarde."
                    : "Não foi possível registar a sugestão.");
        } else
        {
            System.out.println("A sugestão não foi registada.");
        }
    }

    private void gerirTrocasParciais()
    { /* este método permite trocar peças da sugestão, uma categoria de cada vez. */
        while (Utils.confirma("Pretende trocar alguma peça da sugestão? (S/N)"))
        {
            List<Categoria> categoriasComPeca = new ArrayList<>();
            for (PecaVestuario p : controller.getSugestao().getPecas())
            {
                if (!categoriasComPeca.contains(p.getCategoria())) categoriasComPeca.add(p.getCategoria());
            }
            if (categoriasComPeca.isEmpty()) return;
            Categoria categoria = Utils.apresentaESeleciona(categoriasComPeca,
                    "Selecione a categoria da peça que pretende trocar:", "Cancelar troca");
            if (categoria == null) return;
            if (controller.trocarPeca(categoria))
            {
                System.out.println("\nNova sugestão:\n" + controller.obterSugestao());
            } else
            {
                System.out.println("Não existem mais peças adequadas nessa categoria.");
            }
        }
    }

    private List<Categoria> selecionaCategorias(List<Categoria> disponiveis)
    { /* este método seleciona categorias. */
        List<Categoria> restantes = new ArrayList<>(disponiveis);
        List<Categoria> selecionadas = new ArrayList<>();
        boolean continuar = true;
        while (continuar)
        {
            while (!restantes.isEmpty())
            {
                Categoria c = Utils.apresentaESeleciona(restantes,
                        "Categorias disponíveis (escolha uma de cada vez):", "Terminar seleção");
                if (c == null) break;
                selecionadas.add(c);
                restantes.remove(c);
            }
            if (selecionadas.isEmpty())
            {
                System.out.println("--> Não selecionou nenhuma categoria.");
                continuar = Utils.confirma("Pretende selecionar categorias? (S/N)");
                restantes = new ArrayList<>(disponiveis);
            } else continuar = false;
        }
        return selecionadas;
    }
}
