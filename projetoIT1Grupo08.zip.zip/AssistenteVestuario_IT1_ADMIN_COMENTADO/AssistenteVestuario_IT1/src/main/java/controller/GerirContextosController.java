package controller;

import domain.ContextoUtilizacao;
import domain.Plataforma;

import java.util.List;

/** controlador grasp do uc05 - gerir contextos de utilização. */
public class GerirContextosController
{
    private final Plataforma plataforma;
    private ContextoUtilizacao contexto;

    /** @param plataforma repositório do domínio */
    public GerirContextosController(Plataforma plataforma) { /* este método prepara uma nova instância desta classe. */ this.plataforma = plataforma; }

    /** @return contextos do utilizador atual */
    public List<ContextoUtilizacao> getContextos() { /* este método devolve contextos. */ return plataforma.getContextos(); }
    /** @return true se existe sessão */
    public boolean temUtilizadorAtivo() { /* este método verifica se utilizador ativo. */ return plataforma.temUtilizadorAtivo(); }
    /** prepara um novo contexto. */
    public void novoContexto() { /* este método cria ou prepara contexto. */ contexto = plataforma.novoContexto(); }
    /** seleciona um contexto existente. */
    public void selecionarContexto(ContextoUtilizacao contexto) { /* este método seleciona contexto. */ this.contexto = contexto; }
    /** @return contexto selecionado */
    public ContextoUtilizacao getContexto() { /* este método devolve contexto. */ return contexto; }

    /** define os dados do contexto em criação. */
    public void setDados(String ocasiao, String clima, String formalidade)
    { /* este método atualiza dados. */
        contexto.setOcasiao(ocasiao);
        contexto.setClima(clima);
        contexto.setFormalidade(formalidade);
    }

    /** valida o contexto novo. */
    public String validar()
    { /* este método valida o contexto em criação. */
        if (contexto == null || !contexto.valida())
            return "Dados em falta ou inválidos (ocasião, clima e formalidade são obrigatórios).";
        if (plataforma.existeContexto(contexto)) return "Já existe um contexto igual registado.";
        return null;
    }

    /** valida dados de edição sem considerar o próprio contexto como duplicado. */
    public String validarEdicao(String ocasiao, String clima, String formalidade)
    { /* este método valida edicao. */
        ContextoUtilizacao candidato = new ContextoUtilizacao(contexto == null ? null : contexto.getProprietario(),
                ocasiao, clima, formalidade);
        if (!candidato.valida())
            return "Dados em falta ou inválidos (ocasião, clima e formalidade são obrigatórios).";
        for (ContextoUtilizacao c : plataforma.getContextos())
        {
            if (c != contexto && c.equals(candidato)) return "Já existe um contexto igual registado.";
        }
        return null;
    }

    /** @return dados do contexto */
    public String obterDados() { /* este método devolve dados. */ return contexto == null ? "" : contexto.obterDados(); }
    /** @return true se registado */
    public boolean registarContexto() { /* este método regista contexto. */ return plataforma.registarContexto(contexto); }
    /** @return true se editado */
    public boolean editarContexto(String ocasiao, String clima, String formalidade)
    { /* este método edita contexto. */
        return plataforma.editarContexto(contexto, ocasiao, clima, formalidade);
    }
    /** @return true se removido */
    public boolean removerContexto() { /* este método remove contexto. */ return plataforma.removerContexto(contexto); }
}
