package controller;

import domain.Avaliacao;
import domain.Plataforma;
import domain.SugestaoRoupa;

import java.util.List;

/**
 * controlador grasp do uc07 - avaliar sugestão.
 */
public class AvaliarSugestao_Controller {
    private final Plataforma plataforma;
    private SugestaoRoupa sugestao;
    private Avaliacao avaliacao;

    public AvaliarSugestao_Controller(Plataforma plataforma) { /* este método prepara uma nova instância desta classe. */
        this.plataforma = plataforma;
    }

    /**
     * @return true se existe utilizador autenticado
     */
    public boolean temUtilizadorAtivo() { /* este método verifica se utilizador ativo. */
        return plataforma.temUtilizadorAtivo();
    }

    /**
     * @return sugestões do utilizador atual
     */
    public List<SugestaoRoupa> getSugestoes() { /* este método devolve sugestoes. */
        return plataforma.getHistoricoSugestoes();
    }

    /**
     * seleciona sugestão a avaliar.
     */
    public void selecionarSugestao(SugestaoRoupa sugestao) { /* este método seleciona sugestao. */
        this.sugestao = sugestao;
    }

    /**
     * @return true se a sugestão selecionada já foi avaliada
     */
    public boolean sugestaoJaAvaliada() { /* este método indica se a sugestão já foi avaliada. */
        return sugestao != null && sugestao.isAvaliada();
    }

    /**
     * @return texto da sugestão
     */
    public String obterSugestao() { /* este método devolve sugestao. */
        return sugestao == null ? "" : sugestao.obterSugestao();
    }

    /**
     * prepara uma avaliação.
     */
    public void novaAvaliacao(int pontuacao, String comentario) { /* este método cria ou prepara avaliacao. */
        avaliacao = plataforma.criarAvaliacao(pontuacao, comentario);
    }

    /**
     * @return mensagem de erro ou null
     */
    public String validar() { /* este método valida a avaliação em criação. */
        if (avaliacao == null || !avaliacao.valida())
            return "Pontuação inválida: tem de estar entre " + Avaliacao.PONTUACAO_MINIMA + " e " + Avaliacao.PONTUACAO_MAXIMA + ".";
        return null;
    }

    /**
     * @return dados da avaliação
     */
    public String obterDados() { /* este método devolve dados. */
        return avaliacao == null ? "" : avaliacao.obterDados();
    }

    /**
     * @return true se registada
     */
    public boolean registarAvaliacao() { /* este método regista avaliacao. */
        return plataforma.registarAvaliacao(sugestao, avaliacao);
    }
}
