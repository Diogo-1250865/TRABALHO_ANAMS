package utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UncheckedIOException;
import java.util.List;

/**
 * funções utilitárias para a leitura de dados da consola (adaptado do código-base).
 *
 * @author paulo maio &amp; dulce mota (código-base), adaptado
 */
public class Utils
{
    // um único leitor partilhado: criar um bufferedreader novo em cada leitura pode perder dados já lidos.
    private static final BufferedReader ENTRADA = new BufferedReader(new InputStreamReader(System.in));

    private Utils()
    { /* este método prepara uma nova instância desta classe. */
    }

    /**
     * apresenta o texto e lê uma linha da consola.
     *
     * @param strPrompt texto a apresentar
     * @return a linha lida, sem espaços nas pontas
     * @throws EntradaTerminadaException se a entrada de dados terminou
     */
    public static String readLineFromConsole(String strPrompt)
    { /* este método apresenta uma mensagem e lê uma linha da consola. */
        System.out.println(strPrompt);
        try
        {
            String linha = ENTRADA.readLine();
            if (linha == null)
            {
                throw new EntradaTerminadaException();
            }
            return linha.trim();
        } catch (IOException e)
        {
            throw new UncheckedIOException(e);
        }
    }

    /**
     * lê um número inteiro, repetindo o pedido enquanto o valor introduzido não for válido.
     *
     * @param strPrompt texto a apresentar
     * @return o inteiro lido
     */
    public static int IntFromConsole(String strPrompt)
    { /* este método lê um número inteiro da consola. */
        while (true)
        {
            String texto = readLineFromConsole(strPrompt);
            try
            {
                return Integer.parseInt(texto);
            } catch (NumberFormatException ex)
            {
                System.out.println("--> Valor inválido: introduza um número inteiro.");
            }
        }
    }

    /**
     * pergunta s/n ao utilizador.
     *
     * @param sMessage pergunta a apresentar
     * @return true se a resposta for "s" (sem distinguir maiúsculas)
     */
    public static boolean confirma(String sMessage)
    { /* este método pede uma confirmação com resposta s ou n. */
        String resposta;
        do
        {
            resposta = readLineFromConsole(sMessage);
        } while (!resposta.equalsIgnoreCase("s") && !resposta.equalsIgnoreCase("n"));

        return resposta.equalsIgnoreCase("s");
    }

    /**
     * apresenta uma lista numerada e pede a seleção de um elemento.
     *
     * @param list    elementos a apresentar
     * @param sHeader cabeçalho
     * @param <T>     tipo dos elementos
     * @return o elemento escolhido, ou null se o utilizador escolher 0 (cancelar)
     */
    public static <T> T apresentaESeleciona(List<T> list, String sHeader)
    {
        return apresentaESeleciona(list, sHeader, "Cancelar");
    }

    /**
     * como {@link #apresentaESeleciona(List, String)}, com texto personalizado para a opção 0.
     *
     * @param list       elementos a apresentar
     * @param sHeader    cabeçalho
     * @param textoZero  texto da opção 0
     * @param <T>        tipo dos elementos
     * @return o elemento escolhido, ou null se o utilizador escolher 0
     */
    public static <T> T apresentaESeleciona(List<T> list, String sHeader, String textoZero)
    {
        apresentaLista(list, sHeader, textoZero);
        return selecionaObject(list);
    }

    public static void apresentaLista(List<?> list, String sHeader, String textoZero)
    { /* este método apresenta lista. */
        System.out.println(sHeader);

        int index = 0;
        for (Object o : list)
        {
            index++;
            System.out.println(index + ". " + o);
        }
        System.out.println();
        System.out.println("0 - " + textoZero);
    }

    public static <T> T selecionaObject(List<T> list)
    {
        int nOpcao;
        do
        {
            nOpcao = IntFromConsole("Introduza opção: ");
        } while (nOpcao < 0 || nOpcao > list.size());

        return nOpcao == 0 ? null : list.get(nOpcao - 1);
    }
}
