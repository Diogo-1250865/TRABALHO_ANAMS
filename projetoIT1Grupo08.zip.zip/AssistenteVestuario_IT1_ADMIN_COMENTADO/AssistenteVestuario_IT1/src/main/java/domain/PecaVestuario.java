package domain;

import java.io.Serializable;

import java.util.Locale;
import java.util.Objects;

/** peça de vestuário do roupeiro de um utilizador (uc04). */
public class PecaVestuario implements Serializable
{
    private static final long serialVersionUID = 1L;
    private static final String STRING_POR_OMISSAO = "a definir";
    private static final String[] FORMATOS_SUPORTADOS = {".jpg", ".jpeg", ".png"};

    private String nome;
    private Categoria categoria;
    private Estilo estilo;
    private String cor;
    private String tamanho;
    private String marca;
    private String fotografia;
    private Utilizador proprietario;

    /** cria uma peça por preencher. */
    public PecaVestuario()
    { /* este método prepara uma nova instância desta classe. */
        this(null, STRING_POR_OMISSAO, null, null, STRING_POR_OMISSAO, STRING_POR_OMISSAO, "", "");
    }

    /** cria uma peça sem proprietário explícito (compatibilidade com testes). */
    public PecaVestuario(String nome, Categoria categoria, Estilo estilo,
                         String cor, String tamanho, String marca, String fotografia)
    { /* este método prepara uma nova instância desta classe. */
        this(null, nome, categoria, estilo, cor, tamanho, marca, fotografia);
    }

    /** cria uma peça associada ao utilizador indicado. */
    public PecaVestuario(Utilizador proprietario, String nome, Categoria categoria, Estilo estilo,
                         String cor, String tamanho, String marca, String fotografia)
    { /* este método prepara uma nova instância desta classe. */
        this.proprietario = proprietario;
        setNome(nome);
        setCategoria(categoria);
        setEstilo(estilo);
        setCor(cor);
        setTamanho(tamanho);
        setMarca(marca);
        setFotografia(fotografia);
    }

    /** @return proprietário */
    public Utilizador getProprietario() { /* este método devolve proprietario. */ return proprietario; }
    /** @param proprietario proprietário */
    public void setProprietario(Utilizador proprietario) { /* este método atualiza proprietario. */ this.proprietario = proprietario; }
    /** @return nome */
    public String getNome() { /* este método devolve nome. */ return nome; }
    /** @param nome nome */
    public void setNome(String nome) { /* este método atualiza nome. */ this.nome = nome; }
    /** @return categoria */
    public Categoria getCategoria() { /* este método devolve categoria. */ return categoria; }
    /** @param categoria categoria */
    public void setCategoria(Categoria categoria) { /* este método atualiza categoria. */ this.categoria = categoria; }
    /** @return estilo */
    public Estilo getEstilo() { /* este método devolve estilo. */ return estilo; }
    /** @param estilo estilo */
    public void setEstilo(Estilo estilo) { /* este método atualiza estilo. */ this.estilo = estilo; }
    /** @return cor */
    public String getCor() { /* este método devolve cor. */ return cor; }
    /** @param cor cor */
    public void setCor(String cor) { /* este método atualiza cor. */ this.cor = cor; }
    /** @return tamanho */
    public String getTamanho() { /* este método devolve tamanho. */ return tamanho; }
    /** @param tamanho tamanho */
    public void setTamanho(String tamanho) { /* este método atualiza tamanho. */ this.tamanho = tamanho; }
    /** @return marca */
    public String getMarca() { /* este método devolve marca. */ return marca; }
    /** @param marca marca */
    public void setMarca(String marca) { /* este método atualiza marca. */ this.marca = marca; }
    /** @return caminho da fotografia */
    public String getFotografia() { /* este método devolve fotografia. */ return fotografia; }
    /** @param fotografia caminho da fotografia */
    public void setFotografia(String fotografia) { /* este método atualiza fotografia. */ this.fotografia = fotografia; }

    /** @return true se os dados obrigatórios e fotografia são válidos */
    public boolean valida()
    { /* este método valida os dados do objeto. */
        return preenchido(nome) && !nome.equals(STRING_POR_OMISSAO)
                && categoria != null && categoria.valida()
                && estilo != null && estilo.valida()
                && preenchido(cor) && !cor.equals(STRING_POR_OMISSAO)
                && preenchido(tamanho) && !tamanho.equals(STRING_POR_OMISSAO)
                && validaFotografia();
    }

    private boolean validaFotografia()
    { /* este método valida fotografia. */
        if (fotografia == null || fotografia.isBlank()) return true;
        String minuscula = fotografia.trim().toLowerCase(Locale.ROOT);
        for (String formato : FORMATOS_SUPORTADOS)
        {
            if (minuscula.endsWith(formato)) return true;
        }
        return false;
    }

    private static boolean preenchido(String texto)
    { /* este método verifica se o texto está preenchido. */
        return texto != null && !texto.isBlank();
    }

    /** @return texto com os dados da peça */
    public String obterDados()
    { /* este método devolve dados. */
        return "Nome: " + nome
                + " | Categoria: " + categoria
                + " | Estilo: " + estilo
                + " | Cor: " + cor
                + " | Tamanho: " + tamanho
                + " | Marca: " + (preenchido(marca) ? marca : "-")
                + " | Fotografia: " + (preenchido(fotografia) ? fotografia : "-");
    }

    /** duas peças são iguais pelos dados funcionais, independentemente do proprietário. */
    @Override
    public boolean equals(Object o)
    { /* este método compara este objeto com outro. */
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PecaVestuario outra = (PecaVestuario) o;
        return norm(nome).equals(norm(outra.nome))
                && Objects.equals(categoria, outra.categoria)
                && norm(cor).equals(norm(outra.cor))
                && norm(tamanho).equals(norm(outra.tamanho))
                && norm(marca).equals(norm(outra.marca));
    }

    @Override
    public int hashCode()
    { /* este método calcula o código hash do objeto. */
        return Objects.hash(norm(nome), categoria, norm(cor), norm(tamanho), norm(marca));
    }

    private static String norm(String texto)
    { /* este método normaliza o texto para comparação. */
        return texto == null ? "" : texto.trim().toLowerCase(Locale.ROOT);
    }

    @Override
    public String toString()
    { /* este método devolve uma representação do objeto em texto. */
        return nome + " [" + categoria + " / " + estilo + " / " + cor + " / " + tamanho + "]";
    }
}
