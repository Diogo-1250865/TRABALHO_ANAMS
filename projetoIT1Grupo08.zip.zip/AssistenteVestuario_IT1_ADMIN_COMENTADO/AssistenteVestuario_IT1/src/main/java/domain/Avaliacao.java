package domain;

import java.io.Serializable;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * avaliação (feedback) dada pelo utilizador a uma sugestão de roupa
 * (uc07 - avaliar sugestão).
 *
 * @author diogo
 */
public class Avaliacao implements Serializable
{
    private static final long serialVersionUID = 1L;
    /** pontuação mínima da escala (a validar com o cliente). */
    public static final int PONTUACAO_MINIMA = 1;
    /** pontuação máxima da escala (a validar com o cliente). */
    public static final int PONTUACAO_MAXIMA = 5;

    private static final DateTimeFormatter FORMATO_DATA = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private int pontuacao;
    private String comentario;
    private final LocalDateTime data;

    public Avaliacao()
    { /* este método prepara uma nova instância desta classe. */
        this.pontuacao = 0;
        this.comentario = "";
        this.data = LocalDateTime.now();
    }

    public Avaliacao(int pontuacao, String comentario)
    { /* este método prepara uma nova instância desta classe. */
        this.setPontuacao(pontuacao);
        this.setComentario(comentario);
        this.data = LocalDateTime.now();
    }

    public int getPontuacao()
    { /* este método devolve pontuacao. */
        return pontuacao;
    }

    public void setPontuacao(int pontuacao)
    { /* este método atualiza pontuacao. */
        this.pontuacao = pontuacao;
    }

    public String getComentario()
    { /* este método devolve comentario. */
        return comentario;
    }

    public void setComentario(String comentario)
    { /* este método atualiza comentario. */
        this.comentario = comentario == null ? "" : comentario;
    }

    public LocalDateTime getData()
    { /* este método devolve data. */
        return data;
    }

    /**
     * validação local: a pontuação tem de estar dentro da escala.
     *
     * @return true se a avaliação é válida
     */
    public boolean valida()
    { /* este método valida os dados do objeto. */
        return pontuacao >= PONTUACAO_MINIMA && pontuacao <= PONTUACAO_MAXIMA;
    }

    public String obterDados()
    { /* este método devolve dados. */
        return "Pontuação: " + pontuacao + "/" + PONTUACAO_MAXIMA
                + " | Comentário: " + (comentario.isBlank() ? "-" : comentario)
                + " | Data: " + data.format(FORMATO_DATA);
    }

    @Override
    public String toString()
    { /* este método devolve uma representação do objeto em texto. */
        return obterDados();
    }
}
