package controller;

import domain.Categoria;
import domain.Estilo;
import domain.PecaVestuario;
import domain.Plataforma;

import java.util.List;

/** controlador grasp do uc04 - registar peça de vestuário. */
public class RegistarPeca_Controller
{
    private final Plataforma plataforma;
    private PecaVestuario peca;

    public RegistarPeca_Controller(Plataforma plataforma)
    {
        /* este método prepara uma nova instância desta classe. */
        this.plataforma = plataforma;
    }

    /** @return true se existe utilizador autenticado */
    public boolean temUtilizadorAtivo()
    {
        return plataforma.temUtilizadorAtivo();
    }

    /** @return categorias disponíveis */
    public List<Categoria> getCategorias()
    {
        return plataforma.getCategorias();
    }

    /** @return estilos disponíveis */
    public List<Estilo> getEstilos()
    {
        return plataforma.getEstilos();
    }

    /** prepara uma nova peça associada ao utilizador atual. */
    public void novaPeca(
            String nome,
            Categoria categoria,
            Estilo estilo,
            String cor,
            String tamanho,
            String marca,
            String fotografia)
    {
        peca = plataforma.criarPeca(
                nome,
                categoria,
                estilo,
                cor,
                tamanho,
                marca,
                fotografia
        );
    }

    /** @return mensagem de erro ou null */
    public String validar()
    {
        if (!temUtilizadorAtivo())
        {
            return "É necessário iniciar sessão com um utilizador.";
        }

        if (peca == null || !peca.valida())
        {
            return "Dados em falta ou inválidos (nome, categoria, estilo, cor e tamanho são obrigatórios; "
                    + "a fotografia, se indicada, tem de ser .jpg, .jpeg ou .png).";
        }

        if (!plataforma.categoriaEEstiloExistem(peca))
        {
            return "A categoria ou o estilo escolhidos não existem.";
        }

        if (plataforma.existePeca(peca))
        {
            return "Já existe uma peça igual registada no seu roupeiro.";
        }

        return null;
    }

    /** @return dados da peça */
    public String obterDados()
    {
        return peca == null
                ? ""
                : peca.obterDados();
    }

    /** @return true se registada */
    public boolean registarPeca()
    {
        return plataforma.registarPeca(peca);
    }
}