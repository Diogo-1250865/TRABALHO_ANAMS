# Alterações realizadas

1. UC02 e UC03 passaram de “só adicionar” para gestão completa: adicionar, editar e remover.
2. Remoção de categoria/estilo trata peças associadas através de reatribuição obrigatória.
3. UC05 passou a permitir criar, editar e eliminar contextos.
4. Peças, contextos, sugestões e histórico passaram a ficar efetivamente isolados por utilizador.
5. Foi adicionada sessão de utilizador e autenticação por email/password.
6. A palavra-passe passou de SHA-256 simples para SHA-256 + salt aleatório individual.
7. UC06 passou a usar uma regra simples de compatibilidade com a formalidade do contexto.
8. UC06 passou a suportar troca parcial de uma peça por alternativa da mesma categoria.
9. UC07 e UC08 passaram a operar apenas sobre sugestões do utilizador atual.
10. Foram acrescentados testes para CRUD, reatribuição, troca parcial, snapshot de contexto, autenticação e isolamento entre utilizadores.
11. Foi criado o tipo de utilizador (`UTILIZADOR`/`ADMINISTRADOR`).
12. UC02 e UC03 passaram a estar reservados ao administrador; o utilizador normal não vê nem consegue executar essas opções.
13. Foi criado um administrador inicial para demonstração (`admin@vestuario.pt` / `Admin1234!`).
14. Foram adicionados comentários simples em todos os métodos; o texto explicativo dos comentários está em minúsculas.

## Persistência adicionada
- Memória permanente em disco através de serialização Java.
- Gravação automática após operações que alteram dados.
- Carregamento automático no arranque.
- Sessão não é persistida por segurança.
