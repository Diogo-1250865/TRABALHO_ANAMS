package controller;

import domain.Categoria;
import domain.ContextoUtilizacao;
import domain.Estilo;
import domain.Plataforma;
import domain.SugestaoRoupa;

import java.util.List;

/**
 * controlador grasp do uc06 - sugerir roupa.
 */
public class SugerirRoupa_Controller {
    private final Plataforma plataforma;
    private ContextoUtilizacao contexto;
    private Estilo estilo;
    private SugestaoRoupa sugestao;

    public SugerirRoupa_Controller(Plataforma plataforma) { /* este método prepara uma nova instância desta classe. */
        this.plataforma = plataforma;
    }

    /**
     * @return true se existe utilizador autenticado
     */
    public boolean temUtilizadorAtivo() { /* este método verifica se utilizador ativo. */
        return plataforma.temUtilizadorAtivo();
    }

    /**
     * @return contextos do utilizador
     */
    public List<ContextoUtilizacao> getContextos() { /* este método devolve contextos. */
        return plataforma.getContextos();
    }

    /**
     * @return estilos disponíveis
     */
    public List<Estilo> getEstilos() { /* este método devolve estilos. */
        return plataforma.getEstilos();
    }

    /**
     * guarda contexto/estilo e devolve categorias compatíveis.
     */
    public List<Categoria> getCategoriasDisponiveis(ContextoUtilizacao contexto, Estilo estilo) { /* este método devolve categorias disponiveis. */
        this.contexto = contexto;
        this.estilo = estilo;
        return plataforma.getCategoriasDisponiveis(contexto, estilo);// categorias com peças disponíveis e compatíveis com o estilo e o contexto
    }

    /**
     * determina a sugestão inicial.
     */
    public void determinarSugestao(List<Categoria> categoriasSelecionadas) { /* este método determina a sugestão com as categorias selecionadas. */
        sugestao = plataforma.criarSugestao(categoriasSelecionadas, contexto, estilo);
    }

    /**
     * @return mensagem de erro ou null
     */
    public String validar() { /* este método valida a sugestão em criação. */
        if (!temUtilizadorAtivo()) return "É necessário iniciar sessão com um utilizador.";
        if (contexto == null || estilo == null) return "Contexto e estilo são obrigatórios.";
        if (!contexto.compativelCom(estilo))
            return "O estilo selecionado não é compatível com o nível de formalidade do contexto.";
        if (sugestao == null || !sugestao.valida())
            return "Não foi possível sugerir nenhuma peça adequada para as categorias selecionadas.";
        return null;
    }

    /**
     * @return texto da sugestão
     */
    public String obterSugestao() { /* este método devolve sugestao. */
        return sugestao == null ? "" : sugestao.obterSugestao();
    }

    /**
     * @return peças/categorias atuais da sugestão
     */
    public SugestaoRoupa getSugestao() { /* este método devolve sugestao. */
        return sugestao;
    }

    /**
     * tenta substituir a peça de uma categoria pela próxima alternativa adequada.
     */
    public boolean trocarPeca(Categoria categoria) { /* este método troca peca. */
        return plataforma.trocarPecaSugestao(sugestao, categoria);
    }

    /**
     * @return true se a sugestão foi registada
     */
    public boolean registarSugestao() { /* este método regista sugestao. */
        return plataforma.registarSugestao(sugestao);
    }
}
