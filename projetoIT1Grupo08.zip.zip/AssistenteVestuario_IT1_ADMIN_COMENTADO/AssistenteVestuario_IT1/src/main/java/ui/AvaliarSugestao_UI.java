package ui;

import controller.AvaliarSugestao_Controller;
import domain.Avaliacao;
import domain.Plataforma;
import domain.SugestaoRoupa;
import utils.Utils;

import java.util.List;

/** interface de consola do uc07 - avaliar sugestão. */
public class AvaliarSugestao_UI
{
    private final AvaliarSugestao_Controller controller;

    public AvaliarSugestao_UI(Plataforma plataforma)
    { /* este método prepara uma nova instância desta classe. */
        controller = new AvaliarSugestao_Controller(plataforma);
    }

    /** executa o fluxo principal do uc07. */
    public void run()
    { /* este método executa o fluxo principal deste caso de uso. */
        System.out.println("\n=== Avaliar Sugestão ===");
        if (!controller.temUtilizadorAtivo())
        {
            System.out.println("É necessário iniciar sessão com um utilizador.");
            return;
        }

        List<SugestaoRoupa> sugestoes = controller.getSugestoes();
        if (sugestoes.isEmpty())
        {
            System.out.println("Não tem sugestões registadas.");
            return;
        }

        if (!selecionaSugestaoPorAvaliar(sugestoes))
        {
            System.out.println("Operação cancelada.");
            return;
        }

        System.out.println("\nSugestão selecionada:\n" + controller.obterSugestao());
        String erro;
        do
        {
            int pontuacao = Utils.IntFromConsole("Introduza a pontuação (" + Avaliacao.PONTUACAO_MINIMA
                    + " a " + Avaliacao.PONTUACAO_MAXIMA + "): ");
            String comentario = Utils.readLineFromConsole("Introduza um comentário (opcional): ");
            controller.novaAvaliacao(pontuacao, comentario);
            erro = controller.validar();
            if (erro != null)
            {
                System.out.println("--> " + erro);
                if (!Utils.confirma("Pretende corrigir os dados? (S/N)")) return;
            }
        } while (erro != null);

        System.out.println("\nDados da avaliação:\n" + controller.obterDados());
        if (!Utils.confirma("Confirma a avaliação? (S/N)")) return;
        System.out.println(controller.registarAvaliacao()
                ? "Avaliação registada com sucesso."
                : "Não foi possível registar a avaliação.");
    }

    private boolean selecionaSugestaoPorAvaliar(List<SugestaoRoupa> sugestoes)
    { /* este método seleciona sugestao por avaliar. */
        while (true)
        {
            SugestaoRoupa s = Utils.apresentaESeleciona(sugestoes, "Selecione a sugestão a avaliar:");
            if (s == null) return false;
            controller.selecionarSugestao(s);
            if (!controller.sugestaoJaAvaliada()) return true;
            System.out.println("--> Essa sugestão já foi avaliada. Selecione outra.");
        }
    }
}
