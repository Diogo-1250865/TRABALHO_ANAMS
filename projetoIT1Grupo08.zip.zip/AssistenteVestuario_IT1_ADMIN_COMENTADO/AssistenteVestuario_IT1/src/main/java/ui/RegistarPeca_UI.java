package ui;

import controller.RegistarPeca_Controller;
import domain.Categoria;
import domain.Estilo;
import domain.Plataforma;
import utils.Utils;

import java.util.List;

/** interface de consola do uc04 - registar peça de vestuário. */
public class RegistarPeca_UI
{
    private final RegistarPeca_Controller controller;

    public RegistarPeca_UI(Plataforma plataforma)
    { /* este método prepara uma nova instância desta classe. */
        controller = new RegistarPeca_Controller(plataforma);
    }

    /** executa o fluxo principal do uc04. */
    public void run()
    { /* este método executa o fluxo principal deste caso de uso. */
        System.out.println("\n=== Registar Peça de Vestuário ===");
        if (!controller.temUtilizadorAtivo())
        {
            System.out.println("É necessário iniciar sessão com um utilizador.");
            return;
        }

        List<Categoria> categorias = controller.getCategorias();
        List<Estilo> estilos = controller.getEstilos();
        if (categorias.isEmpty() || estilos.isEmpty())
        {
            System.out.println("Não existem categorias ou estilos registados. Operação cancelada.");
            return;
        }

        String erro;
        do
        {
            if (!introduzDados(categorias, estilos))
            {
                System.out.println("Operação cancelada.");
                return;
            }
            erro = controller.validar();
            if (erro != null)
            {
                System.out.println("--> " + erro);
                if (!Utils.confirma("Pretende corrigir os dados? (S/N)"))
                {
                    System.out.println("Operação cancelada.");
                    return;
                }
            }
        } while (erro != null);

        System.out.println("\nDados da peça:\n" + controller.obterDados());
        if (!Utils.confirma("Confirma os dados? (S/N)"))
        {
            System.out.println("Operação cancelada.");
            return;
        }

        System.out.println(controller.registarPeca()
                ? "Peça registada com sucesso no roupeiro do utilizador atual."
                : "Não foi possível registar a peça.");
    }

    private boolean introduzDados(List<Categoria> categorias, List<Estilo> estilos)
    { /* este método recolhe e introduz dados. */
        String nome = Utils.readLineFromConsole("Introduza o nome/descrição da peça: ");
        Categoria categoria = Utils.apresentaESeleciona(categorias, "Selecione a categoria:");
        if (categoria == null) return false;
        Estilo estilo = Utils.apresentaESeleciona(estilos, "Selecione o estilo:");
        if (estilo == null) return false;
        String cor = Utils.readLineFromConsole("Introduza a cor: ");
        String tamanho = Utils.readLineFromConsole("Introduza o tamanho: ");
        String marca = Utils.readLineFromConsole("Introduza a marca (opcional): ");
        String fotografia = Utils.readLineFromConsole("Introduza o caminho da fotografia (.jpg/.jpeg/.png, opcional): ");
        controller.novaPeca(nome, categoria, estilo, cor, tamanho, marca, fotografia);
        return true;
    }
}
