package domain;

import java.io.Serializable;

import java.util.Locale;
import java.util.Objects;

/**
 * estilo de vestuário (ex.: casual, formal, desportivo).
 * gerido pelo administrador da plataforma.
 *
 * @author diogo
 */
public class Estilo implements Serializable
{
    private static final long serialVersionUID = 1L;
    private static final String STRING_POR_OMISSAO = "a definir";

    private String nome;

    public Estilo()
    { /* este método prepara uma nova instância desta classe. */
        this.setNome(STRING_POR_OMISSAO);
    }

    public Estilo(String nome)
    { /* este método prepara uma nova instância desta classe. */
        this.setNome(nome);
    }

    public String getNome()
    { /* este método devolve nome. */
        return nome;
    }

    public void setNome(String nome)
    { /* este método atualiza nome. */
        this.nome = nome;
    }

    /**
     * validação local: o nome tem de estar preenchido.
     *
     * @return true se o estilo é válido
     */
    public boolean valida()
    { /* este método valida os dados do objeto. */
        return nome != null && !nome.isBlank() && !nome.equals(STRING_POR_OMISSAO);
    }

    public String obterDados()
    { /* este método devolve dados. */
        return "Estilo: " + nome;
    }

    /** dois estilos são iguais se tiverem o mesmo nome (sem distinguir maiúsculas). */
    @Override
    public boolean equals(Object o)
    { /* este método compara este objeto com outro. */
        if (this == o)
        {
            return true;
        }
        if (o == null || getClass() != o.getClass())
        {
            return false;
        }
        return chave().equals(((Estilo) o).chave());
    }

    @Override
    public int hashCode()
    { /* este método calcula o código hash do objeto. */
        return Objects.hash(chave());
    }

    private String chave()
    { /* este método devolve o nome normalizado usado em equals e hashCode. */
        return nome == null ? "" : nome.trim().toLowerCase(Locale.ROOT);
    }

    @Override
    public String toString()
    { /* este método devolve uma representação do objeto em texto. */
        return nome;
    }
}
