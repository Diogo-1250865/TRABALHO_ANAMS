package domain;

import java.io.Serializable;

import java.util.Locale;
import java.util.Objects;

/**
 * categoria de vestuário (ex.: calças, camisas, calçado).
 * gerida pelo administrador da plataforma.
 *
 * @author diogo
 */
public class Categoria implements Serializable
{
    private static final long serialVersionUID = 1L;
    private static final String STRING_POR_OMISSAO = "a definir";

    private String nome;

    public Categoria()
    { /* este método prepara uma nova instância desta classe. */
        this.setNome(STRING_POR_OMISSAO);
    }

    public Categoria(String nome)
    { /* este método prepara uma nova instância desta classe. */
        this.setNome(nome);
    }

    public String getNome()
    { /* este método devolve nome. */
        return nome;
    }

    public void setNome(String nome)
    { /* este método atualiza nome. */
        this.nome = nome;
    }

    /**
     * validação local: o nome tem de estar preenchido.
     *
     * @return true se a categoria é válida
     */
    public boolean valida()
    { /* este método valida os dados do objeto. */
        return nome != null && !nome.isBlank() && !nome.equals(STRING_POR_OMISSAO);
    }

    public String obterDados()
    { /* este método devolve dados. */
        return "Categoria: " + nome;
    }

    /** duas categorias são iguais se tiverem o mesmo nome (sem distinguir maiúsculas). */
    @Override
    public boolean equals(Object o)
    { /* este método compara este objeto com outro. */
        if (this == o)
        {
            return true;
        }
        if (o == null || getClass() != o.getClass())
        {
            return false;
        }
        return chave().equals(((Categoria) o).chave());
    }

    @Override
    public int hashCode()
    { /* este método calcula o código hash do objeto. */
        return Objects.hash(chave());
    }

    private String chave()
    { /* este método devolve o nome normalizado usado em equals e hashCode. */
        return nome == null ? "" : nome.trim().toLowerCase(Locale.ROOT);
    }

    @Override
    public String toString()
    { /* este método devolve uma representação do objeto em texto. */
        return nome;
    }
}
