package utils;

/**
 * lançada quando a entrada de dados da consola termina (fim de ficheiro/ctrl+d),
 * para que a aplicação possa terminar de forma limpa em vez de entrar em ciclo.
 *
 * @author diogo
 */
public class EntradaTerminadaException extends RuntimeException
{
    public EntradaTerminadaException()
    { /* este método prepara uma nova instância desta classe. */
        super("Fim da entrada de dados.");
    }
}
