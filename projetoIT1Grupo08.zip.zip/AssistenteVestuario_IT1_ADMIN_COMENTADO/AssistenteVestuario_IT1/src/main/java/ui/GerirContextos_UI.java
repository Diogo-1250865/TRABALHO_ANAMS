package ui;

import controller.GerirContextosController;
import domain.ContextoUtilizacao;
import domain.Plataforma;
import utils.Utils;

import java.util.List;

/** interface de consola do uc05 - gerir contextos de utilização. */
public class GerirContextos_UI
{
    private final GerirContextosController controller;

    public GerirContextos_UI(Plataforma plataforma)
    { /* este método prepara uma nova instância desta classe. */
        controller = new GerirContextosController(plataforma);
    }

    /** executa criar, editar ou eliminar contexto. */
    public void run()
    { /* este método executa o fluxo principal deste caso de uso. */
        System.out.println("\n=== Gerir Contextos de Utilização ===");
        if (!controller.temUtilizadorAtivo())
        {
            System.out.println("É necessário iniciar sessão com um utilizador.");
            return;
        }

        List<ContextoUtilizacao> existentes = controller.getContextos();
        if (existentes.isEmpty())
        {
            System.out.println("Ainda não existem contextos. Só está disponível a operação Criar.");
            criar();
            return;
        }

        String operacao = Utils.apresentaESeleciona(List.of("Criar", "Editar", "Eliminar"),
                "Selecione a operação:", "Voltar");
        if (operacao == null) return;
        switch (operacao)
        {
            case "Criar" -> criar();
            case "Editar" -> editar();
            case "Eliminar" -> eliminar();
            default -> { }
        }
    }

    private void criar()
    { /* este método cria ou prepara um novo objeto. */
        controller.novoContexto();
        String[] dados;
        String erro;
        do
        {
            dados = lerDados();
            controller.setDados(dados[0], dados[1], dados[2]);
            erro = controller.validar();
            if (erro != null && !corrigirOuCancelar(erro)) return;
        } while (erro != null);

        System.out.println("\nDados do contexto:\n" + controller.obterDados());
        if (!Utils.confirma("Confirma os dados? (S/N)")) return;
        System.out.println(controller.registarContexto() ? "Contexto registado com sucesso." : "Não foi possível registar o contexto.");
    }

    private void editar()
    { /* este método edita . */
        ContextoUtilizacao contexto = Utils.apresentaESeleciona(controller.getContextos(),
                "Selecione o contexto a editar:", "Voltar");
        if (contexto == null) return;
        controller.selecionarContexto(contexto);
        System.out.println("Dados atuais: " + controller.obterDados());

        String[] dados;
        String erro;
        do
        {
            dados = lerDados();
            erro = controller.validarEdicao(dados[0], dados[1], dados[2]);
            if (erro != null && !corrigirOuCancelar(erro)) return;
        } while (erro != null);

        if (!Utils.confirma("Confirma a alteração? (S/N)")) return;
        System.out.println(controller.editarContexto(dados[0], dados[1], dados[2])
                ? "Contexto alterado com sucesso." : "Não foi possível alterar o contexto.");
    }

    private void eliminar()
    { /* este método remove o contexto escolhido, após confirmação. */
        ContextoUtilizacao contexto = Utils.apresentaESeleciona(controller.getContextos(),
                "Selecione o contexto a eliminar:", "Voltar");
        if (contexto == null) return;
        controller.selecionarContexto(contexto);
        System.out.println("Contexto: " + controller.obterDados());
        if (!Utils.confirma("Confirma a eliminação? (S/N)")) return;
        System.out.println(controller.removerContexto() ? "Contexto eliminado com sucesso." : "Não foi possível eliminar o contexto.");
    }

    private String[] lerDados()
    { /* este método pede a ocasião, o clima e a formalidade. */
        String ocasiao = Utils.readLineFromConsole("Introduza a ocasião (ex.: trabalho, desporto, evento formal): ");
        String clima = Utils.readLineFromConsole("Introduza o clima (ex.: frio, calor, chuva): ");
        String formalidade = Utils.readLineFromConsole("Introduza a formalidade (baixa, média ou alta): ");
        return new String[]{ocasiao, clima, formalidade};
    }

    private boolean corrigirOuCancelar(String erro)
    { /* este método trata um erro e permite corrigir ou cancelar. */
        System.out.println("--> " + erro);
        if (Utils.confirma("Pretende corrigir os dados? (S/N)")) return true;
        System.out.println("Operação cancelada.");
        return false;
    }
}
